/**
 * @Project NUKEVIET 4.x
 * @Author VINADES.,JSC (contact@vinades.vn)
 * @Copyright (C) 2015 VINADES.,JSC. All rights reserved
 * @License GNU/GPL version 2 or any later version
 * @Createdate Tue, 08 Sep 2015 03:18:03 GMT
 */
function view_detail(a_ob, popup, url){
	$('#idmodals').removeData('bs.modal');
    $('#idmodals').on('show.bs.modal', function () {
    	$('#idmodals .modal-body').load( url);
    }).modal();
 }
 
 function cartorder_detail(id,alias) {
					
					var tk = "";
 					var ngay_nhan = $('#ngay_nhan').val();
 					var ngay_tra = $('#ngay_tra').val();
 					var so_luong = $('#so_luong').val();
					var roomsid = "#rooms"+id;
					var so_luong = $(roomsid).val();
					if(ngay_nhan !="")
					{
						tk = tk + "&ngay_nhan="+ngay_nhan;
					}
					if(ngay_tra !="")
					{
						tk = tk + "&ngay_tra="+ngay_tra;
					}
					if(so_luong !="")
					{
						tk = tk + "&so_luong="+so_luong;
					}
					parent.location = nv_base_siteurl + "index.php?" + nv_lang_variable + "=" + nv_lang_data + "&" + nv_name_variable + "=" + nv_module_name + "&" + nv_fc_variable + "=booking/"+alias+tk;
					
}


			function so_luong_change(str)
			{
				var gia = $('#gia_phongne').val();
				var gia_tong = parseInt(gia) * str;
				var res = $.number( gia_tong, 0 );

				  $('#sl_phong').text(str);
				  $('.gia_do').text(res +"đ");
			}
		

