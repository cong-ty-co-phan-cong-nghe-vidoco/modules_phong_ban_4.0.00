<?php
/**
 * @Project Roomlist Resort Hon Rom in NUKEVIET 4.x
 * @Author Web24.vn (info@web24.vn)
 * @Copyright (C) 2015 NhatnamCorp. All rights reserved
 * @Createdate Tue, 08 Sep 2015 03:18:03 GMT
 */

if ( ! defined( 'NV_SYSTEM' ) ) die( 'Stop!!!' );

define( 'NV_IS_MOD_PHONG', true );

$count_op = sizeof( $array_op );
if( ! empty( $array_op ) and $op == 'main' )
{
	if ($count_op>0){
		$op="detail";
		$alias_cat_url = isset( $array_op[0] ) ? $array_op[0] : '';
		$sql = 'SELECT * FROM ' . NV_PREFIXLANG . '_' . $module_data .'_rows';
		$list = $nv_Cache->db( $sql, 'id', $module_name );
		foreach( $list as $l )
		{
			if( $alias_cat_url == $l['alias'] )
			{
				$id = $l['id'];
			}
		}
	}
}else if($op == 'booking'){
	$alias_cat_url = isset( $array_op[1] ) ? $array_op[1] : '';
	if(empty($alias_cat_url))
		$op="main";
	else{
		$sql = 'SELECT * FROM ' . NV_PREFIXLANG . '_' . $module_data .'_rows';
		$list = $nv_Cache->db( $sql, 'id', $module_name );
		foreach( $list as $l )
		{
			if( $alias_cat_url == $l['alias'] )
			{
				$id = $l['id'];
			}
		}
	}
}else if($op == 'popup'){
	$alias_cat_url = isset( $array_op[1] ) ? $array_op[1] : '';
	if(empty($alias_cat_url))
		$op="main";
	else{
		$sql = 'SELECT * FROM ' . NV_PREFIXLANG . '_' . $module_data .'_rows';
		$list = $nv_Cache->db( $sql, 'id', $module_name );
		foreach( $list as $l )
		{
			if( $alias_cat_url == $l['alias'] )
			{
				$id = $l['id'];
			}
		}
	}
}