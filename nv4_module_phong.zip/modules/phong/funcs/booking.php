<?php

/**
 * @Project Roomlist Resort Hon Rom in NUKEVIET 4.x
 * @Author Web24.vn (info@web24.vn)
 * @Copyright (C) 2015 NhatnamCorp. All rights reserved
 * @Createdate Tue, 08 Sep 2015 03:18:03 GMT
 */

if ( ! defined( 'NV_IS_MOD_PHONG' ) ) die( 'Stop!!!' );

if(isset($_REQUEST['fname']))
{
	$fname = $_REQUEST['fname'];
	$fphone = $_REQUEST['fphone'];
	$femail = $_REQUEST['femail'];
	$faddress = $_REQUEST['faddress'];
	$tinhthanh = $_REQUEST['tinhthanh'];
	$quocgia = $_REQUEST['quocgia'];
	
	$so_luong = $_REQUEST['so_luong'];
	$thanhtoan = $_REQUEST['thanhtoan'];
	$ngay_hien_tai =  NV_CURRENTTIME;
	
	$tra_phong = $_REQUEST['tra_phong']; 
	$ngay_nhan = $_REQUEST['nhan_phong'];
	
	if (preg_match('/^([0-9]{1,2})\/([0-9]{1,2})\/([0-9]{4})$/', $tra_phong, $m)) {
        $phour = $nv_Request->get_int('phour', 'post', 0);
        $pmin = $nv_Request->get_int('pmin', 'post', 0);
        $tra_phong = mktime($phour, $pmin, 0, $m[2], $m[1], $m[3]);
		}
		
		if (preg_match('/^([0-9]{1,2})\/([0-9]{1,2})\/([0-9]{4})$/', $ngay_nhan, $m)) {
        $phour = $nv_Request->get_int('phour', 'post', 0);
        $pmin = $nv_Request->get_int('pmin', 'post', 0);
        $ngay_nhan = mktime($phour, $pmin, 0, $m[2], $m[1], $m[3]);
		}
	//PRINT_R($tra_phong);DIE;
	$stmt = $db->prepare( 'INSERT INTO ' . NV_PREFIXLANG . '_' . $module_data . '_booking (cus_name, cus_tel, cus_email, cus_address, tinh_thanh, nuoc, id_sp, so_luong, checkin_date, checkout_date, dateup, thanhtoan) VALUES (:cus_name, :cus_tel, :cus_email, :cus_address, :tinh_thanh, :nuoc, :id_sp, :so_luong, :checkin_date, :checkout_date, :dateup, :thanhtoan)' );
	
	$stmt->bindParam( ':cus_name', $fname, PDO::PARAM_STR );
			$stmt->bindParam( ':cus_tel', $fphone, PDO::PARAM_STR );
			$stmt->bindParam( ':cus_email', $femail, PDO::PARAM_STR );
			$stmt->bindParam( ':cus_address', $faddress, PDO::PARAM_STR );
			$stmt->bindParam( ':tinh_thanh', $tinhthanh, PDO::PARAM_STR );
			$stmt->bindParam( ':nuoc', $quocgia, PDO::PARAM_STR );
			$stmt->bindParam( ':id_sp', $id, PDO::PARAM_INT );
			$stmt->bindParam( ':so_luong', $so_luong, PDO::PARAM_INT );
			$stmt->bindParam( ':checkin_date', $ngay_nhan, PDO::PARAM_INT );
			$stmt->bindParam( ':checkout_date', $tra_phong, PDO::PARAM_INT );
			$stmt->bindParam( ':dateup', $ngay_hien_tai, PDO::PARAM_INT );
			$stmt->bindParam( ':thanhtoan', $thanhtoan, PDO::PARAM_STR );
			

			$exc = $stmt->execute();
			if( $exc )
			{
				$nv_Cache->delMod( $module_name );
				Header( 'Location: ' . NV_BASE_SITEURL . 'index.php?' . NV_LANG_VARIABLE . '=' . NV_LANG_DATA . '&' . NV_NAME_VARIABLE . '=' . $module_name .'&ok=1');
				die();
			}
	
}
$page_title = $module_info['custom_title'];
$key_words = $module_info['keywords'];

$query = $db->query('SELECT * FROM ' . NV_PREFIXLANG . '_' . $module_data .'_rows WHERE id=' .$id)->fetch();


		$query['conlai'] = $query['rooms'];
// ket thuc lay so luong phong con trong


	$ngay_nhan = $_REQUEST['ngay_nhan'];
	$ngay_tra = $_REQUEST['ngay_tra'];
	$so_luong = $_REQUEST['so_luong'];
		if($so_luong == "")
			$so_luong = 1;
$contents = nv_theme_phong_booking( $query,$province,$ngay_nhan,$ngay_tra,$so_luong);

include NV_ROOTDIR . '/includes/header.php';
echo nv_site_theme( $contents );
include NV_ROOTDIR . '/includes/footer.php';
