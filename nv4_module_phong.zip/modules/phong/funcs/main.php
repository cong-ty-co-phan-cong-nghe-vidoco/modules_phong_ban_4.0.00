<?php

/**
 * @Project Roomlist Resort Hon Rom in NUKEVIET 4.x
 * @Author Web24.vn (info@web24.vn)
 * @Copyright (C) 2015 NhatnamCorp. All rights reserved
 * @Createdate Tue, 08 Sep 2015 03:18:03 GMT
 */

if ( ! defined( 'NV_IS_MOD_PHONG' ) ) die( 'Stop!!!' );

$page_title = $module_info['custom_title'];
$key_words = $module_info['keywords'];
$base_url = NV_BASE_SITEURL . NV_LANG_DATA ."/". $module_name ."/";
$array_data = array();

$query = $db->query('SELECT * FROM ' . NV_PREFIXLANG . '_' . $module_data .'_rows');
while( $row = $query->fetch() )
{
	$base_url_rewrite = nv_url_rewrite( $base_url .$row['alias'] . $global_config['rewrite_exturl'], true );
	$row['link'] = $base_url_rewrite;
	$row['booking'] = nv_url_rewrite( $base_url ."booking/" .$row['alias'] . $global_config['rewrite_exturl'], true );
	$row['popup'] = nv_url_rewrite( $base_url ."popup/" .$row['alias'] . $global_config['rewrite_exturl'], true );
	$row['img'] = (!empty($row['home_img'])? (NV_BASE_SITEURL . NV_UPLOADS_DIR . '/' . $module_name . '/' .$row['home_img']) :(NV_BASE_SITEURL ."themes/default/logo.png"));
	//persons limit
	for ($i=0;$i<$row['persons_men'];$i++)
		$row['persons'] .= "<i class='fa fa-user'></i> ";
		
	//price
	//$row['price'] = number_format($row['price']);
	$row['price'] = number_format($row['price'],0,",",".");
	
			$array_data[$row['id']] = $row;
		
	
}

$currency = $db->query('SELECT * FROM ' . NV_PREFIXLANG . '_' . $module_data .'_config')->fetch();
$ngay_nhan = "";
$ngay_tra = "";
$nguoi_lon = "";
$treem = "";
if(isset($_REQUEST['submit_tk']))
{
	$array_data = array();
	
	$diemden = $_REQUEST['diemden'];
	$ngay_nhan = $_REQUEST['ngay_nhan'];
	$ngay_tra = $_REQUEST['ngay_tra'];
	
		
	$where = " WHERE status =1 ";
	if($diemden != 0)
	{
		$where .= " AND id = ". $diemden;
	}

	$sql = 'SELECT * FROM ' . NV_PREFIXLANG . '_' . $module_data .'_rows'.$where ;
	
	$kq = $db->query($sql);
	while( $row = $kq->fetch() )
	{
		$base_url_rewrite = nv_url_rewrite( $base_url .$row['alias'] . $global_config['rewrite_exturl'], true );
		$row['link'] = $base_url_rewrite;
		$row['booking'] = nv_url_rewrite( $base_url ."booking/" .$row['alias'] . $global_config['rewrite_exturl'], true );
		$row['popup'] = nv_url_rewrite( $base_url ."popup/" .$row['alias'] . $global_config['rewrite_exturl'], true );
		$row['img'] = (!empty($row['home_img'])? (NV_BASE_SITEURL . NV_UPLOADS_DIR . '/' . $module_name . '/' .$row['home_img']) :(NV_BASE_SITEURL ."themes/default/logo.png"));
		//persons limit
		 for ($i=0;$i<$row['persons_men'];$i++)
			$row['persons'] .= "<i class='fa fa-user'></i> ";
		//price
		$row['price'] = number_format($row['price']);
			
			$array_data[$row['id']] = $row;
		
		
	}
}
$ok = $_REQUEST['ok'];
$contents = nv_theme_phong_main( $array_data,$currency['currency'],$ngay_nhan,$ngay_tra,$nguoi_lon,$treem,$loaiphong,$ok);

include NV_ROOTDIR . '/includes/header.php';
echo nv_site_theme($contents);
include NV_ROOTDIR . '/includes/footer.php';
