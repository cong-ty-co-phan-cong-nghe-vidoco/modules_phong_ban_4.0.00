<?php

/**
 * @Project Roomlist Resort Hon Rom in NUKEVIET 4.x
 * @Author Web24.vn (info@web24.vn)
 * @Copyright (C) 2015 NhatnamCorp. All rights reserved
 * @Createdate Tue, 08 Sep 2015 03:18:03 GMT
 */

if ( ! defined( 'NV_IS_MOD_PHONG' ) ) die( 'Stop!!!' );

$page_title = $module_info['custom_title'];
$key_words = $module_info['keywords'];
$base_url = NV_BASE_SITEURL . NV_LANG_DATA ."/". $module_name ."/";
$array_facilities = array();
$array_others = array();
$otherimage = array();

$query = $db->query('SELECT * FROM ' . NV_PREFIXLANG . '_' . $module_data .'_rows WHERE id=' .$id)->fetch();
$currency = $db->query('SELECT * FROM ' . NV_PREFIXLANG . '_' . $module_data .'_config')->fetch();

$query['img'] = (!empty($query['home_img'])? (NV_BASE_SITEURL . NV_UPLOADS_DIR . '/' . $module_name . '/' .$query['home_img']) :(NV_BASE_SITEURL ."themes/default/logo.png"));
$base_url = NV_BASE_SITEURL . NV_LANG_DATA ."/". $module_name ."/";	
//price
//$query['price'] = number_format($query['price']);
$query['price'] = number_format($query['price'],0,",",".");
$query['discount'] = number_format($query['discount'],0,",",".");
$query['note_extrabed'] = nl2br($query['note_extrabed']);
$query['note_price'] = nl2br($query['note_price']);
$query['booking'] = nv_url_rewrite( $base_url ."booking/" .$query['alias'] . $global_config['rewrite_exturl'], true );
$facilities = $db->query('SELECT * FROM ' . NV_PREFIXLANG . '_' . $module_data .'_facilities ORDER BY id DESC');
while( $row = $facilities->fetch() )
{
	$array_facilities[$row['id']] = $row;
}
if (!empty($query['others_img'])){
	$otherimage = explode( '|', $query['others_img'] );
}

//others
$others = $db->query('SELECT * FROM ' . NV_PREFIXLANG . '_' . $module_data .'_rows WHERE id<>' .$id.' ORDER BY weight ASC');
while( $row = $others->fetch() )
{
	$row['img'] = (!empty($row['home_img'])? (NV_BASE_SITEURL . NV_UPLOADS_DIR . '/' . $module_name . '/' .$row['home_img']) :(NV_BASE_SITEURL ."themes/default/logo.png"));
	$base_url_rewrite = nv_url_rewrite( $base_url .$row['alias'] . $global_config['rewrite_exturl'], true );
	$row['link'] = $base_url_rewrite;
	$array_others[$row['id']] = $row;
}
// comment
if( isset( $site_mods['comment'] ) and isset( $module_config[$module_name]['activecomm'] ) )
{
        define( 'NV_COMM_ID', $id ); //ID bài viết
    define( 'NV_COMM_AREA', $module_info['funcs'][$op]['func_id'] );//để đáp ứng comment ở bất cứ đâu không cứ là bài viết
    //check allow comemnt
    $allowed = $module_config[$module_name]['allowed_comm'];//tuy vào module để lấy cấu hình. Nếu là module news thì có cấu hình theo bài viết
    if( $allowed == '-1' )
    {
       $allowed = $news_contents['allowed_comm'];
    }
    define( 'NV_PER_PAGE_COMMENT', 5 ); //Số bản ghi hiển thị bình luận
    require_once NV_ROOTDIR . '/modules/comment/comment.php';
    $area = ( defined( 'NV_COMM_AREA' ) ) ? NV_COMM_AREA : 0;
    $checkss = md5( $module_name . '-' . $area . '-' . NV_COMM_ID . '-' . $allowed . '-' . NV_CACHE_PREFIX );

    //get url comment
    $url_info = parse_url( $client_info['selfurl'] );
    $content_comment = nv_comment_module( $module_name, $checkss, $area, NV_COMM_ID, $allowed, 1 );
}
else
{
        $content_comment = '';
}
$contents = nv_theme_phong_detail( $query,$array_others,$array_facilities,$otherimage,$currency['currency'],$content_comment );


include NV_ROOTDIR . '/includes/header.php';
echo nv_site_theme($contents);
include NV_ROOTDIR . '/includes/footer.php';
