<?php

/**
 * @Project Roomlist Resort Hon Rom in NUKEVIET 4.x
 * @Author Web24.vn (info@web24.vn)
 * @Copyright (C) 2015 NhatnamCorp. All rights reserved
 * @Createdate Tue, 08 Sep 2015 03:18:03 GMT
 */

if ( ! defined( 'NV_IS_MOD_PHONG' ) ) die( 'Stop!!!' );

if ( $nv_Request->isset_request( 'ngay_nhan', 'get' ) )
{
	$ngay_nhan = $nv_Request->get_title( 'ngay_nhan', 'get', '' );
	$ngay_tra = $nv_Request->get_title( 'ngay_tra', 'get', '' );
	$id_room = $nv_Request->get_int( 'id_room', 'get',0);
	$sl = $nv_Request->get_int( 'sl', 'get',0);
	
	if (preg_match('/^([0-9]{1,2})\/([0-9]{1,2})\/([0-9]{4})$/', $ngay_nhan, $m)) {
        $phour = $nv_Request->get_int('phour', 'post', 0);
        $pmin = $nv_Request->get_int('pmin', 'post', 0);
        $ngay_nhan = mktime($phour, $pmin, 0, $m[2], $m[1], $m[3]);
		}
		
		if (preg_match('/^([0-9]{1,2})\/([0-9]{1,2})\/([0-9]{4})$/', $ngay_tra, $m)) {
        $phour = $nv_Request->get_int('phour', 'post', 0);
        $pmin = $nv_Request->get_int('pmin', 'post', 0);
        $ngay_tra = mktime($phour, $pmin, 0, $m[2], $m[1], $m[3]);
		}
		
	if(($ngay_nhan >= NV_CURRENTTIME) and ($ngay_tra >= NV_CURRENTTIME) and ($id_room > 0) and ($sl > 0))
			{
				
				// kiểm tra còn phòng nào trống trong ngày $ngay_nhan - $ngay_tra
				//print_r('SELECT * FROM ' . NV_PREFIXLANG . '_' . $module_data .'_booking WHERE id_sp ='.$id_room.' AND checkout_date >'. NV_CURRENTTIME);die;
				// LẤY DANH SÁCH ĐẶT PHÒNG NÀY CÓ NGÀY TRẢ > NGÀY HIỆN TẠI
				$list_order = $db->query('SELECT * FROM ' . NV_PREFIXLANG . '_' . $module_data .'_booking WHERE id_sp ='.$id_room.' AND checkout_date >'. NV_CURRENTTIME)->fetchAll();
				
				$demphongtrong = 0;
				
				foreach($list_order as $order)
				{
					// KIỂM TRA XEM NGÀY NHẬN VÀ NGÀY TRẢ CÓ NẰM TRONG NGÀY ĐẶT TRƯỚC CHƯA
					
					if((($ngay_nhan >= $order['checkin_date']) and ($ngay_nhan <= $order['checkout_date'])) or (($ngay_tra >= $order['checkin_date']) and ($ngay_tra <= $order['checkout_date'])))
						$demphongtrong++;
				}
				
				// LẤY SỐ PHÒNG CỦA id_room ra
				$rooms = $db->query('SELECT rooms FROM ' . NV_PREFIXLANG . '_' . $module_data .'_rows WHERE id ='.$id_room)->fetchColumn();
				
				if( ($rooms - $demphongtrong) >= $sl)
				{
					die('con');// còn
				}
				else
				{
					die('het');// hết
				}
	}
}


$page_title = $module_info['custom_title'];
$key_words = $module_info['keywords'];
$base_url = NV_BASE_SITEURL . NV_LANG_DATA ."/". $module_name ."/";
$array_data = array();

$query = $db->query('SELECT * FROM ' . NV_PREFIXLANG . '_' . $module_data .'_rows');
while( $row = $query->fetch() )
{
	$base_url_rewrite = nv_url_rewrite( $base_url .$row['alias'] . $global_config['rewrite_exturl'], true );
	$row['link'] = $base_url_rewrite;
	$row['booking'] = nv_url_rewrite( $base_url ."booking/" .$row['alias'] . $global_config['rewrite_exturl'], true );
	$row['popup'] = nv_url_rewrite( $base_url ."popup/" .$row['alias'] . $global_config['rewrite_exturl'], true );
	$row['img'] = (!empty($row['home_img'])? (NV_BASE_SITEURL . NV_UPLOADS_DIR . '/' . $module_name . '/' .$row['home_img']) :(NV_BASE_SITEURL ."themes/default/logo.png"));
	//persons limit
	for ($i=0;$i<$row['persons_men'];$i++)
		$row['persons'] .= "<i class='fa fa-user'></i> ";
		
	//price
	$row['price'] = number_format($row['price']);
	
			$array_data[$row['id']] = $row;
		
	
}

$currency = $db->query('SELECT * FROM ' . NV_PREFIXLANG . '_' . $module_data .'_config')->fetch();
$ngay_nhan = "";
$ngay_tra = "";
$nguoi_lon = "";
$treem = "";
if(isset($_REQUEST['submit_tk']))
{
	$array_data = array();
	
	$diemden = $_REQUEST['diemden'];
	$ngay_nhan = $_REQUEST['ngay_nhan'];
	$ngay_tra = $_REQUEST['ngay_tra'];
	
		
	$where = " WHERE status =1 ";
	if($diemden != 0)
	{
		$where .= " AND id = ". $diemden;
	}

	$sql = 'SELECT * FROM ' . NV_PREFIXLANG . '_' . $module_data .'_rows'.$where ;
	
	$kq = $db->query($sql);
	

	while( $row = $kq->fetch() )
	{
	
		
		$base_url_rewrite = nv_url_rewrite( $base_url .$row['alias'] . $global_config['rewrite_exturl'], true );
		$row['link'] = $base_url_rewrite;
		$row['booking'] = nv_url_rewrite( $base_url ."booking/" .$row['alias'] . $global_config['rewrite_exturl'], true );
		$row['popup'] = nv_url_rewrite( $base_url ."popup/" .$row['alias'] . $global_config['rewrite_exturl'], true );
		$row['img'] = (!empty($row['home_img'])? (NV_BASE_SITEURL . NV_UPLOADS_DIR . '/' . $module_name . '/' .$row['home_img']) :(NV_BASE_SITEURL ."themes/default/logo.png"));
		//persons limit
		 for ($i=0;$i<$row['persons_men'];$i++)
			$row['persons'] .= "<i class='fa fa-user'></i> ";
		//price
		$row['price'] = number_format($row['price']);
		
		// kiểm tra xem có ngày bắt đầu thuê và ngày kết thúc không
		
		if (preg_match('/^([0-9]{1,2})\/([0-9]{1,2})\/([0-9]{4})$/', $ngay_nhan, $m)) {
        $phour = $nv_Request->get_int('phour', 'post', 0);
        $pmin = $nv_Request->get_int('pmin', 'post', 0);
        $ngay_nhan = mktime($phour, $pmin, 0, $m[2], $m[1], $m[3]);
		}
		
		if (preg_match('/^([0-9]{1,2})\/([0-9]{1,2})\/([0-9]{4})$/', $ngay_tra, $m)) {
        $phour = $nv_Request->get_int('phour', 'post', 0);
        $pmin = $nv_Request->get_int('pmin', 'post', 0);
        $ngay_tra = mktime($phour, $pmin, 0, $m[2], $m[1], $m[3]);
		}
		
		if(($ngay_nhan >= NV_CURRENTTIME) and ($ngay_tra >= NV_CURRENTTIME))
		{
			
			// kiểm tra còn phòng nào trống trong ngày $ngay_nhan - $ngay_tra
			
			// LẤY DANH SÁCH ĐẶT PHÒNG NÀY CÓ NGÀY TRẢ > NGÀY HIỆN TẠI
			$list_order = $db->query('SELECT * FROM ' . NV_PREFIXLANG . '_' . $module_data .'_booking WHERE id_sp ='.$row['id'].' AND checkout_date >'. NV_CURRENTTIME)->fetchAll();
			
			$demphongtrong = 0;
			
			foreach($list_order as $order)
			{
				// KIỂM TRA XEM NGÀY NHẬN VÀ NGÀY TRẢ CÓ NẰM TRONG NGÀY ĐẶT TRƯỚC CHƯA
				
				if((($ngay_nhan >= $order['checkin_date']) and ($ngay_nhan <= $order['checkout_date'])) or (($ngay_tra >= $order['checkin_date']) and ($ngay_tra <= $order['checkout_date'])))
					$demphongtrong++;
			}
			//print_r($row['rooms']);die;
			if($demphongtrong < $row['rooms'])
			{
				$array_data[$row['id']] = $row;
			}
			
		}
		else
		{		
			$array_data[$row['id']] = $row;
		}
		
		
	}
}
$ok = $_REQUEST['ok'];
$contents = nv_theme_phong_main( $array_data,$currency['currency'],$ngay_nhan,$ngay_tra,$nguoi_lon,$treem,$loaiphong,$ok);

include NV_ROOTDIR . '/includes/header.php';
echo nv_site_theme($contents);
include NV_ROOTDIR . '/includes/footer.php';
