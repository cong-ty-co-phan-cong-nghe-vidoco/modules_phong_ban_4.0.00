<?php

/**
 * @Project Roomlist Resort Hon Rom in NUKEVIET 4.x
 * @Author Web24.vn (info@web24.vn)
 * @Copyright (C) 2015 NhatnamCorp. All rights reserved
 * @Createdate Tue, 08 Sep 2015 03:18:03 GMT
 */

if ( ! defined( 'NV_IS_MOD_PHONG' ) ) die( 'Stop!!!' );

$page_title = $module_info['custom_title'];
$key_words = $module_info['keywords'];

$array_facilities = array();

$query = $db->query('SELECT * FROM ' . NV_PREFIXLANG . '_' . $module_data .'_rows WHERE id=' .$id)->fetch();
$currency = $db->query('SELECT * FROM ' . NV_PREFIXLANG . '_' . $module_data .'_config')->fetch();

$query['img'] = (!empty($query['home_img'])? (NV_BASE_SITEURL . NV_UPLOADS_DIR . '/' . $module_name . '/' .$query['home_img']) :(NV_BASE_SITEURL ."themes/default/logo.png"));
		
//price
$query['price'] = number_format($query['price']);
$query['note_extrabed'] = nl2br($query['note_extrabed']);
$query['note_price'] = nl2br($query['note_price']);

$facilities = $db->query('SELECT * FROM ' . NV_PREFIXLANG . '_' . $module_data .'_facilities');
while( $row = $facilities->fetch() )
{
	$array_facilities[$row['id']] = $row;
}
if (!empty($query['others_img'])){
	$otherimage = explode( '|', $query['others_img'] );
}

$contents = nv_theme_phong_popup( $query,$array_facilities,$otherimage,$currency['currency'] );

echo $contents;
