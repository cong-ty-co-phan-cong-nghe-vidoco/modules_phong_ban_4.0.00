<?php

/**
 * @Project NUKEVIET 4.x
 * @Author VINADES.,JSC (contact@vinades.vn)
 * @Copyright (C) 2015 VINADES.,JSC. All rights reserved
 * @License GNU/GPL version 2 or any later version
 * @Createdate Tue, 08 Sep 2015 03:18:03 GMT
 */

if ( ! defined( 'NV_ADMIN' ) or ! defined( 'NV_MAINFILE' ) or ! defined( 'NV_IS_MODADMIN' ) ) die( 'Stop!!!' );

$submenu['facilities'] = $lang_module['facilities'];
$submenu['booking'] = $lang_module['booking'];
$submenu['config'] = $lang_module['config'];

$allow_func = array( 'main', 'config', 'cat', 'facilities', 'booking','excel');

define( 'NV_IS_FILE_ADMIN', true );

function approve_alias($alias_old,$id,$db){
	global $db_config, $module_data;
	
	$stmt = $db->prepare( 'SELECT COUNT(*) FROM ' . NV_PREFIXLANG . '_' . $module_data . '_rows WHERE id !=' . $id . ' AND alias = :alias' );
	$stmt->bindParam( ':alias', $alias_old, PDO::PARAM_STR );
	$stmt->execute();
	
	if( $stmt->fetchColumn() )
	{
		$weight = $db->query( 'SELECT MAX(id) FROM ' . NV_PREFIXLANG . '_' . $module_data .'_rows' )->fetchColumn();
		$weight = intval( $weight ) + 1;
		$alias = $alias_old . '-' . $weight;
	}else
		$alias = $alias_old;
	return $alias;
}
function get_facilites($facilities){
	global $db_config, $module_data, $db;
	$query = $db->query("SELECT * FROM " .NV_PREFIXLANG . "_" . $module_data . "_facilities");
	while ($facilities = $query->fetch()){
		$facilities['name'] = "fac".$facilities['id'];
		$xtpl->assign( 'facilities', $facilities );
		//$xtpl->assign( 'selected', $selected );
		$xtpl->parse( 'main.facilities' );
	}

}
?>