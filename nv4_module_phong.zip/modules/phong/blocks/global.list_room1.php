<?php

/**
 * @Project NUKEVIET 4.x
 * @Author VINADES.,JSC (contact@vinades.vn)
 * @Copyright (C) 2014 VINADES.,JSC. All rights reserved
 * @License GNU/GPL version 2 or any later version
 * @Createdate Sat, 10 Dec 2011 06:46:54 GMT
 */

if( ! defined( 'NV_MAINFILE' ) ) die( 'Stop!!!' );

if( ! nv_function_exists( 'nv_block_list_room_dv' ) )
{
	function nv_block_list_room_groups_dv( $module, $data_block, $lang_block )
	{
		global $site_mods;

		$html_input = '';
		$html = '';
		$html .= '<tr>';
		$html .= '<td>' . $lang_block['blockid'] . '</td>';
		$html .= '<td><select name="config_blockid" class="form-control w200">';
		$html .= '<option value="0"> -- </option>';
		$sql = 'SELECT * FROM ' . NV_PREFIXLANG . '_' . $site_mods[$module]['module_data'] . '_block_cat ORDER BY weight ASC';
		$list = $nv_Cache->db( $sql, '', $module );
		foreach( $list as $l )
		{
			$html_input .= '<input type="hidden" id="config_blockid_' . $l['bid'] . '" value="' . NV_BASE_SITEURL . 'index.php?' . NV_LANG_VARIABLE . '=' . NV_LANG_DATA . '&amp;' . NV_NAME_VARIABLE . '=' . $module . '&amp;' . NV_OP_VARIABLE . '=' . $site_mods[$module]['alias']['groups'] . '/' . $l['alias'] . '" />';
			$html .= '<option value="' . $l['bid'] . '" ' . ( ( $data_block['blockid'] == $l['bid'] ) ? ' selected="selected"' : '' ) . '>' . $l['title'] . '</option>';
		}
		$html .= '</select>';
		$html .= $html_input;
		$html .= '<script type="text/javascript">';
		$html .= '	$("select[name=config_blockid]").change(function() {';
		$html .= '		$("input[name=title]").val($("select[name=config_blockid] option:selected").text());';
		$html .= '		$("input[name=link]").val($("#config_blockid_" + $("select[name=config_blockid]").val()).val());';
		$html .= '	});';
		$html .= '</script>';
		$html .= '</tr>';
		$html .= '<tr>';
		$html .= '<td>' . $lang_block['numrow'] . '</td>';
		$html .= '<td><input type="text" class="form-control w200" name="config_numrow" size="5" value="' . $data_block['numrow'] . '"/></td>';
		$html .= '</tr>';
		return $html;
	}

	function nv_block_config_list_room_submit_dv( $module, $lang_block )
	{
		global $nv_Request;
		$return = array();
		$return['error'] = array();
		$return['config'] = array();
		$return['config']['blockid'] = $nv_Request->get_int( 'config_blockid', 'post', 0 );
		$return['config']['numrow'] = $nv_Request->get_int( 'config_numrow', 'post', 0 );
		return $return;
	}

	function nv_block_list_room_dv( $block_config )
	{
		global $module_array_cat, $module_info, $site_mods, $module_config, $global_config, $db,$module_name, $nv_Cache, $lang_module;
		$module = $block_config['module'];
		$base_url = NV_BASE_SITEURL . $module ."/";
		$db->sqlreset()
			->select( '*' )
			->from( NV_PREFIXLANG . '_' . $site_mods[$module]['module_data'] . '_rows' )
			->limit( $block_config['numrow'] )
			->order( 'weight ASC' );
		$list = $nv_Cache->db( $db->sql(), '', $module );

		
		if( ! empty( $list ) )
		{
			$xtpl = new XTemplate( 'block.list_room1.tpl', NV_ROOTDIR . '/themes/default/modules/phong' );
			$xtpl->assign( 'NV_BASE_SITEURL', NV_BASE_SITEURL );
			$xtpl->assign( 'TEMPLATE', $block_theme );
			
			  // Language
            if (file_exists(NV_ROOTDIR . '/modules/phong/language/' . NV_LANG_DATA . '.php')) {
                require_once NV_ROOTDIR . '/modules/phong/language/' . NV_LANG_DATA . '.php';
            }
			
			$xtpl->assign('LANG', $lang_module);

			$j = 1;
			foreach( $list as $row )
			{
				$base_url_rewrite = nv_url_rewrite( $base_url .$row['alias'] . $global_config['rewrite_exturl'], true );
				$row['link'] = $base_url_rewrite;
				$row['home_img'] = (!empty($row['home_img'])? (NV_BASE_SITEURL . NV_UPLOADS_DIR . '/' . $site_mods[$module]['module_upload'] . '/' .$row['home_img']) :(NV_BASE_SITEURL ."themes/default/logo.png"));
				
				$row['img'] = (!empty($row['home_img_orther'])? (NV_BASE_SITEURL . NV_UPLOADS_DIR . '/' . $site_mods[$module]['module_upload'] . '/' .$row['home_img_orther']) :($row['home_img']));
				
				
				//persons limit
				for ($i=0;$i<$row['persons_limit'];$i++)
					$row['persons'] .= "<i class='fa fa-user'></i> ";
					
				//price
				$row['price'] = number_format($row['price']);
				$xtpl->assign( 'room', $row );
				if($j == 1)
				$xtpl->parse( 'main.dau' );
				else 
				$xtpl->parse( 'main.loop' );
				
				$j = 2;
			}
			$xtpl->assign( 'NV_BASE_SITEURL', NV_BASE_SITEURL );
			$xtpl->parse( 'main' );
			return $xtpl->text( 'main' );
		}
	}
}
if( defined( 'NV_SYSTEM' ) )
{
		$content = nv_block_list_room_dv( $block_config );
}
