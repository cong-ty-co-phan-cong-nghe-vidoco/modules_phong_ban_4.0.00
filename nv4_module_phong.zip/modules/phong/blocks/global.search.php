<?php

/**
 * @Project NUKEVIET 4.x
 * @Author VINADES.,JSC (contact@vinades.vn)
 * @Copyright (C) 2014 VINADES.,JSC. All rights reserved
 * @License GNU/GPL version 2 or any later version
 * @Createdate Sat, 10 Dec 2011 06:46:54 GMT
 */

if( ! defined( 'NV_MAINFILE' ) ) die( 'Stop!!!' );

if( ! nv_function_exists( 'nv_block_list_room1' ) )
{
	function nv_block_list_room_groups1( $module, $data_block, $lang_block )
	{
		global $site_mods;

		$html_input = '';
		$html = '';
		$html .= '<tr>';
		$html .= '<td>' . $lang_block['blockid'] . '</td>';
		$html .= '<td><select name="config_blockid" class="form-control w200">';
		$html .= '<option value="0"> -- </option>';
		$sql = 'SELECT * FROM ' . NV_PREFIXLANG . '_' . $site_mods[$module]['module_data'] . '_block_cat ORDER BY weight ASC';
		$list = $nv_Cache->db( $sql, '', $module );
		foreach( $list as $l )
		{
			$html_input .= '<input type="hidden" id="config_blockid_' . $l['bid'] . '" value="' . NV_BASE_SITEURL . 'index.php?' . NV_LANG_VARIABLE . '=' . NV_LANG_DATA . '&amp;' . NV_NAME_VARIABLE . '=' . $module . '&amp;' . NV_OP_VARIABLE . '=' . $site_mods[$module]['alias']['groups'] . '/' . $l['alias'] . '" />';
			$html .= '<option value="' . $l['bid'] . '" ' . ( ( $data_block['blockid'] == $l['bid'] ) ? ' selected="selected"' : '' ) . '>' . $l['title'] . '</option>';
		}
		$html .= '</select>';
		$html .= $html_input;
		$html .= '<script type="text/javascript">';
		$html .= '	$("select[name=config_blockid]").change(function() {';
		$html .= '		$("input[name=title]").val($("select[name=config_blockid] option:selected").text());';
		$html .= '		$("input[name=link]").val($("#config_blockid_" + $("select[name=config_blockid]").val()).val());';
		$html .= '	});';
		$html .= '</script>';
		$html .= '</tr>';
		$html .= '<tr>';
		$html .= '<td>' . $lang_block['numrow'] . '</td>';
		$html .= '<td><input type="text" class="form-control w200" name="config_numrow" size="5" value="' . $data_block['numrow'] . '"/></td>';
		$html .= '</tr>';
		return $html;
	}


	function nv_block_list_room1( $block_config )
	{
		global $module_array_cat, $module_info, $site_mods, $module_config, $global_config, $db,$module_name,$lang_global, $nv_Cache;
		
		$module = $block_config['module'];
		$base_url = NV_BASE_SITEURL . NV_LANG_DATA ."/" . $module;
		$db->sqlreset()
			->select( '*' )
			->from( NV_PREFIXLANG . '_' . $site_mods[$module]['module_data'] . '_rows' )
			->limit( $block_config['numrow'] );
		$list = $nv_Cache->db( $db->sql(), '', $module );

		if( ! empty( $list ) )
		{
			$xtpl = new XTemplate( 'block.search.tpl', NV_ROOTDIR . '/themes/web24/modules/phong' );
			$xtpl->assign( 'NV_BASE_SITEURL', NV_BASE_SITEURL );
			$xtpl->assign( 'TEMPLATE', $block_theme );
			$xtpl->assign( 'LINK_SEACH', $base_url );
			$xtpl->assign( 'LANG', $lang_global );
			$xtpl->assign( 'MODULE_NAME', $site_mods[$module]['module_data']);
			$xtpl->assign( 'OP', 'search' );
			
			$diemden = $_REQUEST['diemden'];
			$ngay_nhan = $_REQUEST['ngay_nhan'];
			$ngay_tra = $_REQUEST['ngay_tra'];
			
			$xtpl->assign( 'ngay_nhan', $ngay_nhan );
			$xtpl->assign( 'ngay_tra', $ngay_tra );
			
			foreach( $list as $row )
			{
				$base_url_rewrite = nv_url_rewrite( $base_url .$row['alias'] . $global_config['rewrite_exturl'], true );
				$row['link'] = $base_url_rewrite;
				$row['img'] = (!empty($row['home_img'])? (NV_BASE_SITEURL . NV_UPLOADS_DIR . '/phong/' .$row['home_img']) :(NV_BASE_SITEURL ."themes/web24/logo.png"));
				//persons limit
				for ($i=0;$i<$row['persons_limit'];$i++)
					$row['persons'] .= "<i class='fa fa-user'></i> ";
					
				//price
				$row['price'] = number_format($row['price']);
				if($diemden == $row['id'] )
					$row['selected'] = 'selected=selected';
				else $row['selected'] = '';
				$xtpl->assign( 'room', $row );
				$xtpl->parse( 'main.block_room_list' );
			}
			$xtpl->assign( 'NV_BASE_SITEURL', NV_BASE_SITEURL );
			$xtpl->parse( 'main' );
			return $xtpl->text( 'main' );
		}
	}
}
if( defined( 'NV_SYSTEM' ) )
{
		$content = nv_block_list_room1( $block_config );
}
