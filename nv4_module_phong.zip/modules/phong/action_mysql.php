<?php

/**
 * @Project NUKEVIET 4.x
 * @Author VINADES.,JSC (contact@vinades.vn)
 * @Copyright (C) 2015 VINADES.,JSC. All rights reserved
 * @License GNU/GPL version 2 or any later version
 * @Createdate Tue, 08 Sep 2015 03:18:03 GMT
 */

if ( ! defined( 'NV_MAINFILE' ) ) die( 'Stop!!!' );

$sql_drop_module = array();
$sql_drop_module[] = "DROP TABLE IF EXISTS `" . NV_PREFIXLANG . "_" . $module_data . "_rows`";

$sql_drop_module[] = "DROP TABLE IF EXISTS `" . NV_PREFIXLANG . "_" . $module_data . "_cat`";

$sql_drop_module[] = "DROP TABLE IF EXISTS `" . NV_PREFIXLANG . "_" . $module_data . "_facilities`";

$sql_drop_module[] = "DROP TABLE IF EXISTS `" . NV_PREFIXLANG . "_" . $module_data . "_booking`";

$sql_drop_module[] = "DROP TABLE IF EXISTS `" . NV_PREFIXLANG . "_" . $module_data . "_config`";
$result = $db->query( "SHOW TABLE STATUS LIKE '" . $db_config['prefix'] . "\_" . $lang . "\_comment'" );
$rows = $result->fetchAll();
if( sizeof( $rows ) )
{
        $sql_drop_module[] = "DELETE FROM " . $db_config['prefix'] . "_" . $lang . "_comment WHERE module='" . $module_name . "'";
}

$sql_create_module = $sql_drop_module;
$sql_create_module[] = "CREATE TABLE `" . NV_PREFIXLANG . "_" . $module_data . "_rows` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `weight` int(11) NOT NULL,
  `title` varchar(250) NOT NULL COMMENT 'Tên phòng',
  `alias` text NOT NULL COMMENT 'Liên kết tĩnh',
  `dimension` varchar(10) NOT NULL COMMENT 'Diện tích',
  `rooms` int(11) NOT NULL COMMENT 'Số lượng phòng',
  `persons_limit` int(11) NOT NULL COMMENT 'Số người tối đa',
  `bed` varchar(250) NOT NULL COMMENT 'Giường ngủ',
  `direct` varchar(250) NOT NULL COMMENT 'Hướng',
  `persons_men` int(11) NOT NULL COMMENT 'Số lượng người lớn',
  `extrabed` varchar(250) NOT NULL COMMENT 'Giường phụ - Trẻ em',
  `note_extrabed` varchar(250) NOT NULL COMMENT 'Ghi chú giường phụ',
  `home_img` varchar(250) NOT NULL COMMENT 'Hình minh họa',
  `home_img_orther` varchar(250) default '' COMMENT 'Hình minh họa khác',
  `others_img` text NOT NULL COMMENT 'Hình ảnh khác',
  `price` varchar(100) NOT NULL COMMENT 'Giá',
  `tien_ich` varchar(100) default '',
  `discount` int(11) NOT NULL COMMENT 'Khuyến mãi',
  `note_price` varchar(250) NOT NULL COMMENT 'Ghi chú giá',
  `hometext` text NOT NULL,
  `des_tien_ich` text NOT NULL,
  `details` text NOT NULL,
  `dateup` int(11) NOT NULL COMMENT 'Ngày cập nhật',
  `status` int(11) NOT NULL default 1,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;";

$sql_create_module[] = "CREATE TABLE `" . NV_PREFIXLANG . "_" . $module_data . "_cat` (
  `catid` int(11) NOT NULL AUTO_INCREMENT,
  `cat_title` varchar(250) NOT NULL,
  `cat_alias` varchar(250) NOT NULL,
  `cat_hometext` text NOT NULL,
  `cat_detail` text NOT NULL,
  `cate_homeimg` varchar(250) NOT NULL,
  `cat_weight` int(11) NOT NULL,
  `cat_dateup` int(11) NOT NULL,
  PRIMARY KEY (`catid`)
) ENGINE=MyISAM;";

$sql_create_module[] = "CREATE TABLE `" . NV_PREFIXLANG . "_" . $module_data . "_facilities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(250) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;";

$sql_create_module[] = "CREATE TABLE `" . NV_PREFIXLANG . "_" . $module_data . "_booking` (
  `book_id` int(11) NOT NULL AUTO_INCREMENT,
  `cus_name` varchar(250) NOT NULL,
  `cus_tel` varchar(20) NOT NULL,
  `cus_email` varchar(250) NOT NULL,
  `cus_address` varchar(250) NOT NULL,
  `tinh_thanh` int DEFAULT 0,
  `nuoc` int DEFAULT 0,
  `id_sp` int NOT NULL,
  `so_luong` int NOT NULL,
  `checkin_date` int NOT NULL,
  `checkout_date` int NOT NULL,
  `adults` int(11) NOT NULL,
  `childs` int(11) NOT NULL,
  `rooms` text NOT NULL,
  `dateup` varchar(250) NOT NULL,
  `thanhtoan` varchar(250) NOT NULL,
  PRIMARY KEY (`book_id`)
) ENGINE=MyISAM;";
$sql_create_module[] = "CREATE TABLE `" . NV_PREFIXLANG . "_" . $module_data . "_config` (
  `currency` varchar(3) NOT NULL
) ENGINE=MyISAM;";

// Comments
$sql_create_module[] = "INSERT INTO " . NV_CONFIG_GLOBALTABLE . " (lang, module, config_name, config_value) VALUES ('" . NV_LANG_DATA . "', '" . $module_name . "', 'auto_postcomm', '1')";
$sql_create_module[] = "INSERT INTO " . NV_CONFIG_GLOBALTABLE . " (lang, module, config_name, config_value) VALUES ('" . NV_LANG_DATA . "', '" . $module_name . "', 'allowed_comm', '6')";
$sql_create_module[] = "INSERT INTO " . NV_CONFIG_GLOBALTABLE . " (lang, module, config_name, config_value) VALUES ('" . NV_LANG_DATA . "', '" . $module_name . "', 'view_comm', '6')";
$sql_create_module[] = "INSERT INTO " . NV_CONFIG_GLOBALTABLE . " (lang, module, config_name, config_value) VALUES ('" . NV_LANG_DATA . "', '" . $module_name . "', 'setcomm', '4')";
$sql_create_module[] = "INSERT INTO " . NV_CONFIG_GLOBALTABLE . " (lang, module, config_name, config_value) VALUES ('" . NV_LANG_DATA . "', '" . $module_name . "', 'activecomm', '1')";
$sql_create_module[] = "INSERT INTO " . NV_CONFIG_GLOBALTABLE . " (lang, module, config_name, config_value) VALUES ('" . NV_LANG_DATA . "', '" . $module_name . "', 'emailcomm', '0')";
$sql_create_module[] = "INSERT INTO " . NV_CONFIG_GLOBALTABLE . " (lang, module, config_name, config_value) VALUES ('" . NV_LANG_DATA . "', '" . $module_name . "', 'adminscomm', '')";
$sql_create_module[] = "INSERT INTO " . NV_CONFIG_GLOBALTABLE . " (lang, module, config_name, config_value) VALUES ('" . NV_LANG_DATA . "', '" . $module_name . "', 'sortcomm', '0')";
$sql_create_module[] = "INSERT INTO " . NV_CONFIG_GLOBALTABLE . " (lang, module, config_name, config_value) VALUES ('" . NV_LANG_DATA . "', '" . $module_name . "', 'captcha', '1')";