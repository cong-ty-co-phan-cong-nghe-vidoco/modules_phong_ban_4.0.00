<?php

/**
 * @Project Roomlist Resort Hon Rom in NUKEVIET 4.x
 * @Author Web24.vn (info@web24.vn)
 * @Copyright (C) 2015 NhatnamCorp. All rights reserved
 * @Createdate Tue, 08 Sep 2015 03:18:03 GMT
 */

if ( ! defined( 'NV_IS_MOD_PHONG' ) ) die( 'Stop!!!' );

/**
 * nv_theme_phong_main()
 * 
 * @param mixed $array_data
 * @return
 */
function nv_theme_phong_main ( $array_data,$currency,$ngay_nhan,$ngay_tra,$nguoi_lon,$treem, $toida,$ok)
{
    global $global_config, $module_name, $module_file, $lang_global, $module_config, $module_info, $op;
	$xtpl = new XTemplate( $op . '.tpl', NV_ROOTDIR . '/themes/' . $module_info['template'] . '/modules/' . $module_file );
    $xtpl->assign( 'LANG', $lang_global );
    $xtpl->assign( 'ngay_nhan', $ngay_nhan );
    $xtpl->assign( 'ngay_tra', $ngay_tra );
    $xtpl->assign( 'nguoi_lon', $nguoi_lon );
    $xtpl->assign( 'treem', $treem );
    $xtpl->assign( 'toida', $toida );
	
	
		for($i = 1; $i < 6 ; $i ++)
		{
			if($i == $toida )
			$xtpl->assign( 'selected','selected=selected');
			else $xtpl->assign( 'selected','');
			$xtpl->assign( 'toida',$i);
			$xtpl->parse( 'main.toida' );
		}
		
		for($i = 1; $i < 6 ; $i ++)
		{
			if($i == $nguoi_lon )
			$xtpl->assign( 'selected','selected=selected');
			else $xtpl->assign( 'selected','');
			$xtpl->assign( 'nguoi_lon',$i);
			$xtpl->parse( 'main.nguoi_lon' );
		}
	
		for($i = 1; $i < 6 ; $i ++)
		{
			if($i == $treem )
			$xtpl->assign( 'selected','selected=selected');
			else $xtpl->assign( 'selected','');
			$xtpl->assign( 'treem',$i);
			$xtpl->parse( 'main.treem' );
		}
	
	
	if($ok == 1)
	{
		$xtpl->assign( 'booking', '1' );
	}
	else $xtpl->assign( 'booking', '0' );
	$i=0;
	foreach ($array_data as $row){
		
		$xtpl->assign( 'id', $row['id'] );
		$xtpl->assign( 'title', $row['title'] );
		$xtpl->parse( 'main.room_search' );
	}
	
	if(empty($array_data))
	{	
		$xtpl->parse( 'main.empty' );
	}
	
	foreach ($array_data as $row){
		
		$bg = (($i++ % 2)?'background-color:#eaeaea':'background-color:#f5f5f5');
		$xtpl->assign( 'bg', $bg );
		$row['note_extrabed'] = nl2br($row['note_extrabed']);
		$orther = NV_BASE_SITEURL . 'index.php?' . NV_LANG_VARIABLE . '=' . NV_LANG_DATA . '&amp;' . NV_NAME_VARIABLE . '=' . $module_name . '&amp;' . NV_OP_VARIABLE . '=booking&id='.$row[id];
		
			 for($i = 1;$i <= $row['rooms'];$i++)
				{
					$xtpl->assign( 'i', $i );
					$xtpl->parse( 'main.room_list.soluong' );
				}
				
			
		$xtpl->assign( 'room', $row );
		$xtpl->assign( 'currency', $currency );
		$xtpl->parse( 'main.room_list' );
	}
	

    $xtpl->parse( 'main' );
    return $xtpl->text( 'main' );
}

/**
 * nv_theme_phong_detail()
 * 
 * @param mixed $array_data
 * @return
 */
function nv_theme_phong_detail ( $array_data,$others,$facilities,$oimg,$currency,  $content_comment)
{
    global $global_config, $module_name, $module_file, $lang_module, $module_config, $module_info, $op ,$client_info;

    $xtpl = new XTemplate( $op . '.tpl', NV_ROOTDIR . '/themes/' . $module_info['template'] . '/modules/' . $module_file );
    $xtpl->assign( 'LANG', $lang_module );
	$xtpl->assign( 'SELFURL', $client_info['selfurl'] );
	$xtpl->assign( 'NV_BASE_SITEURL', NV_BASE_SITEURL);
	$xtpl->assign( 'TEMPLATE', $module_info['template']);
	if( !empty( $content_comment ) )
	{
			$xtpl->assign( 'CONTENT_COMMENT', $content_comment );
			$xtpl->parse( 'main.comment' );
	}
	
	$array_tienich = explode(',',$array_data['tien_ich']);
	foreach ($facilities as $rfaci){
		if(in_array($rfaci['id'],$array_tienich))
		{
			$xtpl->assign( 'facilities', $rfaci );
			$xtpl->parse( 'main.facilities' );
		}
	}
	
	$xtpl->assign( 'currency', $currency );
	$xtpl->assign( 'room', $array_data );
	foreach ($oimg as $others_img){
		$xtpl->assign( 'img', NV_BASE_SITEURL . NV_UPLOADS_DIR . '/' . $module_name . '/' .$others_img );
		$xtpl->parse( 'main.other_img' );
		//$xtpl->parse( 'main.other_img_mobile' );
	}
	foreach($others as $others_room){
		$others_room['price'] = number_format($others_room['price'],0,",",".");
		$others_room['discount'] = number_format($others_room['discount'],0,",",".");
		
		
		$xtpl->assign( 'others', $others_room );
		
		if($others_room['discount'] > 0)
		{
			$xtpl->parse( 'main.others_room.discount' );
		}
		
		
		$xtpl->parse( 'main.others_room' );
	}
	$xtpl->assign( 'NV_BASE_SITEURL', NV_BASE_SITEURL );
    $xtpl->parse( 'main' );
    return $xtpl->text( 'main' );
}
function nv_theme_phong_popup ( $array_data,$facilities,$oimg,$currency )
{
    global $global_config, $module_name, $module_file, $lang_module, $module_config, $module_info, $op;
    $xtpl = new XTemplate( $op . '.tpl', NV_ROOTDIR . '/themes/' . $module_info['template'] . '/modules/' . $module_file );
    $xtpl->assign( 'LANG', $lang_module );
	
	foreach ($facilities as $rfaci){
		$xtpl->assign( 'facilities', $rfaci );
		$xtpl->parse( 'main.facilities' );
	}
	$xtpl->assign( 'currency', $currency );
	$xtpl->assign( 'room', $array_data );
	foreach ($oimg as $others_img){
		$xtpl->assign( 'img', NV_BASE_SITEURL . NV_UPLOADS_DIR . '/' . $module_name . '/' .$others_img );
		$xtpl->parse( 'main.other_img' );
	}
	$xtpl->assign( 'NV_BASE_SITEURL', NV_BASE_SITEURL);
    $xtpl->parse( 'main' );
    return $xtpl->text( 'main' );
}

/**
 * nv_theme_phong_search()
 * 
 * @param mixed $array_data
 * @return
 */
function nv_theme_phong_search ( $array_data )
{
    global $global_config, $module_name, $module_file, $lang_module, $module_config, $module_info, $op;

    $xtpl = new XTemplate( $op . '.tpl', NV_ROOTDIR . '/themes/' . $module_info['template'] . '/modules/' . $module_file );
    $xtpl->assign( 'LANG', $lang_module );

    

    $xtpl->parse( 'main' );
    return $xtpl->text( 'main' );
}

/**
 * nv_theme_phong_viewcat()
 * 
 * @param mixed $array_data
 * @return
 */
function nv_theme_phong_viewcat ( $array_data )
{
    global $global_config, $module_name, $module_file, $lang_module, $module_config, $module_info, $op;

    $xtpl = new XTemplate( $op . '.tpl', NV_ROOTDIR . '/themes/' . $module_info['template'] . '/modules/' . $module_file );
    $xtpl->assign( 'LANG', $lang_module );

    

    $xtpl->parse( 'main' );
    return $xtpl->text( 'main' );
}

/**
 * nv_theme_phong_booking()
 * 
 * @param mixed $array_data
 * @return
 */
function nv_theme_phong_booking ( $array_data,$tinhthanh,$ngay_nhan,$ngay_tra,$so_luong)
{
    global $global_config, $module_name, $module_file, $lang_module, $lang_global, $module_config, $module_info, $op;
    $xtpl = new XTemplate( $op . '.tpl', NV_ROOTDIR . '/themes/' . $module_info['template'] . '/modules/' . $module_file );
    $xtpl->assign( 'LANG', $lang_module );
    $xtpl->assign( 'LANG1', $lang_global );
	$base_url = NV_BASE_SITEURL . $module_name ."/";
	$base_url1 = NV_BASE_SITEURL . $module_name ."/";
    $array_data['img'] = (!empty($array_data['home_img'])? (NV_BASE_SITEURL . NV_UPLOADS_DIR . '/' . $module_name . '/' .$array_data['home_img']) :(NV_BASE_SITEURL ."themes/default/logo.png"));
	$tong_tien = $so_luong * $array_data['price'];
	
	$array_data['gia'] = $array_data['price'];
	$array_data['price'] = number_format($array_data['price'],0,",",".");
	$tong_tien = number_format($tong_tien,0,",",".");
	$array_data['note_extrabed'] = nl2br($array_data['note_extrabed']);
	$array_data['note_price'] = nl2br($array_data['note_price']);
	$xtpl->assign( 'NV_CURRENTTIME', nv_date( "d/m/Y", NV_CURRENTTIME ) );
//	print_r($array_data);die;
	$base_url = nv_url_rewrite( $base_url ."booking/" .$array_data['alias'] . $global_config['rewrite_exturl'], true );
	 $xtpl->assign( 'NV_BASE_SITEURL', $NV_BASE_SITEURL );
	 $xtpl->assign( 'LINK', $base_url );
	 $xtpl->assign( 'LINK1', $base_url1 );
	 $xtpl->assign( 'ROW', $array_data );
	 
	 if(!empty($ngay_nhan))
	 $xtpl->assign( 'ngay_nhan', $ngay_nhan );
	 else  $xtpl->assign( 'ngay_nhan', nv_date( "d/m/Y", NV_CURRENTTIME ) );
	 
	 if(!empty($ngay_tra))
	 $xtpl->assign( 'ngay_tra', $ngay_tra );
	 else  $xtpl->assign( 'ngay_tra', nv_date( "d/m/Y", NV_CURRENTTIME + 86400 ) );
	 
	 $xtpl->assign( 'so_luong', $so_luong );
	 $xtpl->assign( 'tong_tien', $tong_tien );
	 foreach( $tinhthanh as $row)
	 {
		$xtpl->assign( 'TINH', $row );
		$xtpl->parse( 'main.loopcata' );
	 }
	
	 if($array_data['rooms'] <= 0)
			$xtpl->assign( 'hetphong', $lang_module['hetphong'] );
		else{
			 for($i = 1;$i <= $array_data['rooms'];$i++)
				{
					$xtpl->assign( 'i', $i );
					if($i == $so_luong)
					$xtpl->assign( 'select', "selected=selected" );
					else $xtpl->assign( 'select', "" ); 
						
					$xtpl->parse( 'main.soluong.sl' );
				}
				$xtpl->parse( 'main.soluong' );
			}
    $xtpl->parse( 'main' );
    return $xtpl->text( 'main' );
}