<?php

/**
 * @Project NUKEVIET 4.x
 * @Author VINADES.,JSC (contact@vinades.vn)
 * @Copyright (C) 2014 VINADES.,JSC. All rights reserved
 * @License GNU/GPL version 2 or any later version
 * @Createdate 2-9-2010 14:43
 */
	
	require( NV_ROOTDIR . "/includes/class/php-excel.class.php" );
	require( NV_ROOTDIR . "/includes/class/excel_reader.php" );
	
$result = $db->query( 'SELECT * FROM ' . NV_PREFIXLANG . '_' . $module_data . '_booking');

$data[] = array ("STT","Tên phòng","Giá", "Giá đã giả","Họ và tên", "Số điện thoại", "Email", "Địa chỉ", "Số lượng" , "Ngày nhận phòng" , "Ngày trả phòng", "Hình thức thanh toán");
    $i=1;
    while ( $row = $result->fetch() ) 
    {
		$kq_phong = $db->query( 'SELECT * FROM ' . NV_PREFIXLANG . '_' . $module_data . '_rows where id ='.$row["id_sp"])->fetch();
		
		$kq_phong['price'] = number_format($kq_phong['price']);
		if($kq_phong['discount'] == 0)
			$kq_phong['discount'] = $kq_phong['price'];
		else $kq_phong['discount'] = number_format($kq_phong['discount']);
        //$data[] = array ($row['service_title'] ." - " .$row['ngayyeucau'], $row['tel'], $row['email'], $row['cmnd'], $row['keyword'], $row['code']);
		$data[] = array ($i,$kq_phong['title'],$kq_phong['price'], $kq_phong['discount'], $row['cus_name'], $row['cus_tel'] , $row['cus_email'], $row['cus_address'], $row['so_luong'], $row['checkin_date'] ,$row['checkout_date'], $row['thanhtoan']);
    	$i++;
	}
    
    // generate file (constructor parameters are optional)
    $xls = new Excel_XML('UTF-8', false, 'Booking');
    $xls->addArray($data);
    //$xls->generateXML(change_alias($lang_module['register']));
	$xls->generateXML("Danh_Sach_Booking");
