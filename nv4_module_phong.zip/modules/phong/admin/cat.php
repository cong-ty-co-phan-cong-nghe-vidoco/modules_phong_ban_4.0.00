<?php

/**
 * @Project NUKEVIET 4.x
 * @Author VINADES.,JSC (contact@vinades.vn)
 * @Copyright (C) 2015 VINADES.,JSC. All rights reserved
 * @License GNU/GPL version 2 or any later version
 * @Createdate Tue, 08 Sep 2015 03:29:05 GMT
 */

if ( ! defined( 'NV_IS_FILE_ADMIN' ) ) die( 'Stop!!!' );

if ( $nv_Request->isset_request( 'get_alias_title', 'post' ) )
{
	$alias = $nv_Request->get_title( 'get_alias_title', 'post', '' );
	$id = $nv_Request->get_int( 'id', 'post', 0 );
	$alias = approve_cat_alias(change_alias( $alias ),$id,$db);
	
	die( $alias );
}
if ( $nv_Request->isset_request( 'delete_catid', 'get' ) and $nv_Request->isset_request( 'delete_checkss', 'get' ))
{
	$catid = $nv_Request->get_int( 'delete_catid', 'get' );
	$delete_checkss = $nv_Request->get_string( 'delete_checkss', 'get' );
	if( $catid > 0 and $delete_checkss == md5( $catid . NV_CACHE_PREFIX . $client_info['session_id'] ) )
	{
		$db->query('DELETE FROM ' . NV_PREFIXLANG . '_' . $module_data . '_cat  WHERE catid = ' . $db->quote( $catid ) );
		$nv_Cache->delMod( nvtools );
		Header( 'Location: ' . NV_BASE_ADMINURL . 'index.php?' . NV_LANG_VARIABLE . '=' . NV_LANG_DATA . '&' . NV_NAME_VARIABLE . '=' . $module_name . '&' . NV_OP_VARIABLE . '=' . $op );
		die();
	}
}

$row = array();
$error = array();
$row['catid'] = $nv_Request->get_int( 'catid', 'post,get', 0 );
if ( $nv_Request->isset_request( 'submit', 'post' ) )
{
	$row['cat_title'] = $nv_Request->get_title( 'cat_title', 'post', '' );
	$row['cat_alias'] = $nv_Request->get_title( 'cat_alias', 'post', '' );
	$row['cat_hometext'] = $nv_Request->get_string( 'cat_hometext', 'post', '' );
	$row['cat_detail'] = $nv_Request->get_editor( 'cat_detail', '', NV_ALLOWED_HTML_TAGS );
	$row['cate_homeimg'] = $nv_Request->get_title( 'cate_homeimg', 'post', '' );
	if( is_file( NV_DOCUMENT_ROOT . $row['cate_homeimg'] ) )
	{
		$row['cate_homeimg'] = substr( $row['cate_homeimg'], strlen( NV_BASE_SITEURL . NV_UPLOADS_DIR . '/' . $module_name . '/' ) );
	}
	else
	{
		$row['cate_homeimg'] = '';
	}
	$row['cat_weight'] = $nv_Request->get_int( 'cat_weight', 'post', 0 );
	$row['cat_dateup'] = $nv_Request->get_int( 'cat_dateup', 'post', 0 );

	if( empty( $error ) )
	{
		try
		{
			if( empty( $row['catid'] ) )
			{
				$stmt = $db->prepare( 'INSERT INTO ' . NV_PREFIXLANG . '_' . $module_data . '_cat (cat_title, cat_alias, cat_hometext, cat_detail, cate_homeimg, cat_weight, cat_dateup) VALUES (:cat_title, :cat_alias, :cat_hometext, :cat_detail, :cate_homeimg, :cat_weight, :cat_dateup)' );
			}
			else
			{
				$stmt = $db->prepare( 'UPDATE ' . NV_PREFIXLANG . '_' . $module_data . '_cat SET cat_title = :cat_title, cat_alias = :cat_alias, cat_hometext = :cat_hometext, cat_detail = :cat_detail, cate_homeimg = :cate_homeimg, cat_weight = :cat_weight, cat_dateup = :cat_dateup WHERE catid=' . $row['catid'] );
			}
			$stmt->bindParam( ':cat_title', $row['cat_title'], PDO::PARAM_STR );
			$stmt->bindParam( ':cat_alias', $row['cat_alias'], PDO::PARAM_STR );
			$stmt->bindParam( ':cat_hometext', $row['cat_hometext'], PDO::PARAM_STR, strlen($row['cat_hometext']) );
			$stmt->bindParam( ':cat_detail', $row['cat_detail'], PDO::PARAM_STR, strlen($row['cat_detail']) );
			$stmt->bindParam( ':cate_homeimg', $row['cate_homeimg'], PDO::PARAM_STR );
			$stmt->bindParam( ':cat_weight', $row['cat_weight'], PDO::PARAM_INT );
			$stmt->bindParam( ':cat_dateup', $row['cat_dateup'], PDO::PARAM_INT );

			$exc = $stmt->execute();
			if( $exc )
			{
				$nv_Cache->delMod( $module_name );
				Header( 'Location: ' . NV_BASE_ADMINURL . 'index.php?' . NV_LANG_VARIABLE . '=' . NV_LANG_DATA . '&' . NV_NAME_VARIABLE . '=' . $module_name . '&' . NV_OP_VARIABLE . '=' . $op );
				die();
			}
		}
		catch( PDOException $e )
		{
			trigger_error( $e->getMessage() );
			die( $e->getMessage() ); //Remove this line after checks finished
		}
	}
}
elseif( $row['catid'] > 0 )
{
	$row = $db->query( 'SELECT * FROM ' . NV_PREFIXLANG . '_' . $module_data . '_cat WHERE catid=' . $row['catid'] )->fetch();
	if( empty( $row ) )
	{
		Header( 'Location: ' . NV_BASE_ADMINURL . 'index.php?' . NV_LANG_VARIABLE . '=' . NV_LANG_DATA . '&' . NV_NAME_VARIABLE . '=' . $module_name . '&' . NV_OP_VARIABLE . '=' . $op );
		die();
	}
}
else
{
	$row['catid'] = 0;
	$row['cat_title'] = '';
	$row['cat_alias'] = '';
	$row['cat_hometext'] = '';
	$row['cat_detail'] = '';
	$row['cate_homeimg'] = '';
	$row['cat_weight'] = 0;
	$row['cat_dateup'] = 0;
}
if( ! empty( $row['cate_homeimg'] ) and is_file( NV_UPLOADS_REAL_DIR . '/' . $module_name . '/' . $row['cate_homeimg'] ) )
{
	$row['cate_homeimg'] = NV_BASE_SITEURL . NV_UPLOADS_DIR . '/' . $module_name . '/' . $row['cate_homeimg'];
}

if( defined( 'NV_EDITOR' ) ) require_once NV_ROOTDIR . '/' . NV_EDITORSDIR . '/' . NV_EDITOR . '/nv.php';
$row['cat_detail'] = htmlspecialchars( nv_editor_br2nl( $row['cat_detail'] ) );
if( defined( 'NV_EDITOR' ) and nv_function_exists( 'nv_aleditor' ) )
{
	$row['cat_detail'] = nv_aleditor( 'cat_detail', '100%', '300px', $row['cat_detail'] );
}
else
{
	$row['cat_detail'] = '<textarea style="width:100%;height:300px" name="cat_detail">' . $row['cat_detail'] . '</textarea>';
}

// Fetch Limit
$show_view = false;
if ( ! $nv_Request->isset_request( 'id', 'post,get' ) )
{
	$show_view = true;
	$db->sqlreset()
		->select( '*' )
		->from( '' . NV_PREFIXLANG . '_' . $module_data . '_cat' )
		->order( 'catid DESC' );
	$sth = $db->prepare( $db->sql() );
	$sth->execute();
}


$xtpl = new XTemplate( $op . '.tpl', NV_ROOTDIR . '/themes/' . $global_config['module_theme'] . '/modules/' . $module_file );
$xtpl->assign( 'LANG', $lang_module );
$xtpl->assign( 'NV_LANG_VARIABLE', NV_LANG_VARIABLE );
$xtpl->assign( 'NV_LANG_DATA', NV_LANG_DATA );
$xtpl->assign( 'NV_BASE_ADMINURL', NV_BASE_ADMINURL );
$xtpl->assign( 'NV_NAME_VARIABLE', NV_NAME_VARIABLE );
$xtpl->assign( 'NV_OP_VARIABLE', NV_OP_VARIABLE );
$xtpl->assign( 'MODULE_NAME', $module_name );
$xtpl->assign( 'OP', $op );
$xtpl->assign( 'ROW', $row );
if( $show_view )
{
	$number = 0;
	while( $view = $sth->fetch() )
	{
		$view['number'] = ++$number;
		$view['link_edit'] = NV_BASE_ADMINURL . 'index.php?' . NV_LANG_VARIABLE . '=' . NV_LANG_DATA . '&amp;' . NV_NAME_VARIABLE . '=' . $module_name . '&amp;' . NV_OP_VARIABLE . '=' . $op . '&amp;catid=' . $view['catid'];
		$view['link_delete'] = NV_BASE_ADMINURL . 'index.php?' . NV_LANG_VARIABLE . '=' . NV_LANG_DATA . '&amp;' . NV_NAME_VARIABLE . '=' . $module_name . '&amp;' . NV_OP_VARIABLE . '=' . $op . '&amp;delete_catid=' . $view['catid'] . '&amp;delete_checkss=' . md5( $view['catid'] . NV_CACHE_PREFIX . $client_info['session_id'] );
		$xtpl->assign( 'VIEW', $view );
		$xtpl->parse( 'main.view.loop' );
	}
	$xtpl->parse( 'main.view' );
}


if( ! empty( $error ) )
{
	$xtpl->assign( 'ERROR', implode( '<br />', $error ) );
	$xtpl->parse( 'main.error' );
}
if( empty( $row['catid'] ) )
{
	$xtpl->parse( 'main.auto_get_alias' );
}

$xtpl->parse( 'main' );
$contents = $xtpl->text( 'main' );

$page_title = $lang_module['cat'];

include NV_ROOTDIR . '/includes/header.php';
echo nv_admin_theme( $contents );
include NV_ROOTDIR . '/includes/footer.php';