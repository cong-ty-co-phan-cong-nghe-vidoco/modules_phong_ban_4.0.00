<?php

/**
 * @Project NUKEVIET 4.x
 * @Author VINADES.,JSC (contact@vinades.vn)
 * @Copyright (C) 2015 VINADES.,JSC. All rights reserved
 * @License GNU/GPL version 2 or any later version
 * @Createdate Fri, 11 Sep 2015 08:03:44 GMT
 */

if ( ! defined( 'NV_IS_FILE_ADMIN' ) ) die( 'Stop!!!' );

if ( $nv_Request->isset_request( 'get_alias_title', 'post' ) )
{
	$alias = $nv_Request->get_title( 'get_alias_title', 'post', '' );
	$id = $nv_Request->get_int( 'id', 'post', 0 );
	$alias = approve_alias(change_alias( $alias ),$id,$db);
	die( $alias );
}

if( $nv_Request->isset_request( 'ajax_action', 'post' ) )
{
	$id = $nv_Request->get_int( 'id', 'post', 0 );
	$new_vid = $nv_Request->get_int( 'new_vid', 'post', 0 );
	$content = 'NO_' . $id;
	if( $new_vid > 0 )
	{
		$sql = 'SELECT id FROM ' . NV_PREFIXLANG . '_' . $module_data . '_rows WHERE id!=' . $id . ' ORDER BY weight ASC';
		$result = $db->query( $sql );
		$weight = 0;
		while( $row = $result->fetch() )
		{
			++$weight;
			if( $weight == $new_vid ) ++$weight;
			$sql = 'UPDATE ' . NV_PREFIXLANG . '_' . $module_data . '_rows SET weight=' . $weight . ' WHERE id=' . $row['id'];
			$db->query( $sql );
		}
		$sql = 'UPDATE ' . NV_PREFIXLANG . '_' . $module_data . '_rows SET weight=' . $new_vid . ' WHERE id=' . $id;
		$db->query( $sql );
		$content = 'OK_' . $id;
	}
	$nv_Cache->delMod($module_name);
	include NV_ROOTDIR . '/includes/header.php';
	echo $content;
	include NV_ROOTDIR . '/includes/footer.php';
	exit();
}

if ( $nv_Request->isset_request( 'delete_id', 'get' ) and $nv_Request->isset_request( 'delete_checkss', 'get' ))
{
	$id = $nv_Request->get_int( 'delete_id', 'get' );
	$delete_checkss = $nv_Request->get_string( 'delete_checkss', 'get' );
	if( $id > 0 and $delete_checkss == md5( $id . NV_CACHE_PREFIX . $client_info['session_id'] ) )
	{
		$weight=0;
		$sql = 'SELECT weight FROM ' . NV_PREFIXLANG . '_' . $module_data . '_rows WHERE id =' . $db->quote( $id );
		$result = $db->query( $sql );
		list( $weight) = $result->fetch( 3 );
		
		$db->query('DELETE FROM ' . NV_PREFIXLANG . '_' . $module_data . '_rows  WHERE id = ' . $db->quote( $id ) );
		if( $weight > 0)
		{
			$sql = 'SELECT id, weight FROM ' . NV_PREFIXLANG . '_' . $module_data . '_rows WHERE weight >' . $weight;
			$result = $db->query( $sql );
			while(list( $id, $weight) = $result->fetch( 3 ))
			{
				$weight--;
				$db->query( 'UPDATE ' . NV_PREFIXLANG . '_' . $module_data . '_rows SET weight=' . $weight . ' WHERE id=' . intval( $id ));
			}
		}
		$nv_Cache->delMod($module_name);
		Header( 'Location: ' . NV_BASE_ADMINURL . 'index.php?' . NV_LANG_VARIABLE . '=' . NV_LANG_DATA . '&' . NV_NAME_VARIABLE . '=' . $module_name . '&' . NV_OP_VARIABLE . '=' . $op );
		die();
	}
}

$row = array();
$error = array();
$row['id'] = $nv_Request->get_int( 'id', 'post,get', 0 );
if ( $nv_Request->isset_request( 'submit', 'post' ) )
{
	$row['title'] = $nv_Request->get_title( 'title', 'post', '' );
	$alias = $nv_Request->get_title( 'alias', 'post', '' );
	
	$row['alias'] = ( empty($row['alias'] ))? approve_alias(change_alias( $row['title'] ),$row['id'],$db) : approve_alias(change_alias( $alias ),$row['id'],$db);
	$row['dimension'] = $nv_Request->get_title( 'dimension', 'post', '' );
	$row['rooms'] = $nv_Request->get_int( 'rooms', 'post', 0 );
	$row['persons_limit'] = $nv_Request->get_int( 'persons_limit', 'post', 0 );
	$row['persons_men'] = $nv_Request->get_int( 'persons_men', 'post', 0 );
	$row['bed'] = $nv_Request->get_title( 'bed', 'post', '' );
	$row['direct'] = $nv_Request->get_title( 'direct', 'post', '' );
	$row['extrabed'] = $nv_Request->get_title( 'extrabed', 'post', '' );
	$row['note_extrabed'] = $nv_Request->get_title( 'note_extrabed', 'post', '' );
	$row['home_img'] = $nv_Request->get_title( 'home_img', 'post', '' );
	$row['home_img_orther'] = $nv_Request->get_title( 'home_img_orther', 'post', '' );
	
	if( is_file( NV_DOCUMENT_ROOT . $row['home_img'] ) )
	{
		$row['home_img'] = substr( $row['home_img'], strlen( NV_BASE_SITEURL . NV_UPLOADS_DIR . '/' . $module_name . '/' ) );
	}
	else
	{
		$row['home_img'] = '';
	}
	
	if( is_file( NV_DOCUMENT_ROOT . $row['home_img_orther'] ) )
	{
		$row['home_img_orther'] = substr( $row['home_img_orther'], strlen( NV_BASE_SITEURL . NV_UPLOADS_DIR . '/' . $module_name . '/' ) );
	}
	else
	{
		$row['home_img_orther'] = '';
	}
	
	// Xu ly anh minh hoa khac
	
	$otherimage = $nv_Request->get_typed_array( 'otherimage', 'post', 'string' );
	$array_otherimage = array( );
	foreach( $otherimage as $otherimage_i )
	{
		if( !nv_is_url( $otherimage_i ) and file_exists( NV_DOCUMENT_ROOT . $otherimage_i ) )
		{
			$lu = strlen( NV_BASE_SITEURL . NV_UPLOADS_DIR . '/' . $module_upload . '/' );
			$otherimage_i = substr( $otherimage_i, $lu );
		}
		elseif( !nv_is_url( $otherimage_i ) )
		{
			$otherimage_i = '';
		}
		if( !empty( $otherimage_i ) )
		{
			$array_otherimage[] = $otherimage_i;
		}
	}
	$row['others_img'] = implode( '|', $array_otherimage );
	$row['price'] = $nv_Request->get_title( 'price', 'post', '' );
	$row['discount'] = $nv_Request->get_int( 'discount', 'post', 0 );
	$row['note_price'] = $nv_Request->get_title( 'note_price', 'post', '' );
	
	$row['hometext'] = $nv_Request->get_string( 'hometext', 'post', '' );
	$row['des_tien_ich'] = $nv_Request->get_editor( 'des_tien_ich', '', NV_ALLOWED_HTML_TAGS );
	$row['details'] = $nv_Request->get_editor( 'details', '', NV_ALLOWED_HTML_TAGS );
	
	$tien_ich = array_unique( $nv_Request->get_typed_array( 'tien_ich', 'post,get', 'int', array() ) );
	$row['tien_ich'] = implode( ',', $tien_ich );

	if( empty( $error ) )
	{
		try
		{
			if( empty( $row['id'] ) )
			{ 
				$stmt = $db->prepare( 'INSERT INTO ' . NV_PREFIXLANG . '_' . $module_data . '_rows (title, weight, alias, dimension, rooms, persons_limit, bed, direct, persons_men, extrabed, note_extrabed, home_img, home_img_orther, others_img, price, tien_ich, discount, note_price, hometext,des_tien_ich, details, dateup) VALUES (:title, :weight, :alias, :dimension, :rooms, :persons_limit, :bed, :direct, :persons_men, :extrabed, :note_extrabed, :home_img, :home_img_orther, :others_img, :price, :tien_ich, :discount, :note_price, :hometext, :des_tien_ich, :details, ' .NV_CURRENTTIME .')' );
				
				$weight = $db->query( 'SELECT max(weight) FROM ' . NV_PREFIXLANG . '_' . $module_data . '_rows' )->fetchColumn();
			$weight++;	
			$stmt->bindParam( ':weight', $weight, PDO::PARAM_INT );
			}
			else
			{
				$stmt = $db->prepare( 'UPDATE ' . NV_PREFIXLANG . '_' . $module_data . '_rows SET title = :title, alias = :alias, dimension = :dimension, rooms = :rooms, persons_limit = :persons_limit, bed = :bed, direct = :direct, persons_men = :persons_men, extrabed = :extrabed, note_extrabed = :note_extrabed, home_img = :home_img, home_img_orther = :home_img_orther, others_img = :others_img, price = :price, tien_ich =:tien_ich, discount = :discount, note_price = :note_price, hometext = :hometext, des_tien_ich=:des_tien_ich, details = :details WHERE id=' . $row['id'] );
			}
			
			
			$stmt->bindParam( ':title', $row['title'], PDO::PARAM_STR );
			$stmt->bindParam( ':alias', $row['alias'], PDO::PARAM_STR );
			$stmt->bindParam( ':dimension', $row['dimension'], PDO::PARAM_STR );
			$stmt->bindParam( ':rooms', $row['rooms'], PDO::PARAM_INT );
			$stmt->bindParam( ':persons_limit', $row['persons_limit'], PDO::PARAM_INT );
			$stmt->bindParam( ':persons_men', $row['persons_men'], PDO::PARAM_INT );
			$stmt->bindParam( ':bed', $row['bed'], PDO::PARAM_STR );
			$stmt->bindParam( ':direct', $row['direct'], PDO::PARAM_STR );
			$stmt->bindParam( ':extrabed', $row['extrabed'], PDO::PARAM_STR );
			$stmt->bindParam( ':note_extrabed', $row['note_extrabed'], PDO::PARAM_STR );
			$stmt->bindParam( ':home_img', $row['home_img'], PDO::PARAM_STR );
			$stmt->bindParam( ':home_img_orther', $row['home_img_orther'], PDO::PARAM_STR );
			$stmt->bindParam( ':others_img', $row['others_img'], PDO::PARAM_STR );
			$stmt->bindParam( ':price', $row['price'], PDO::PARAM_STR );
			$stmt->bindParam( ':tien_ich', $row['tien_ich'], PDO::PARAM_STR );
			$stmt->bindParam( ':discount', $row['discount'], PDO::PARAM_INT );
			$stmt->bindParam( ':note_price', $row['note_price'], PDO::PARAM_STR );
			$stmt->bindParam( ':hometext', $row['hometext'], PDO::PARAM_STR, strlen($row['hometext']) );
			$stmt->bindParam( ':des_tien_ich', $row['des_tien_ich'], PDO::PARAM_STR, strlen($row['des_tien_ich']) );
			$stmt->bindParam( ':details', $row['details'], PDO::PARAM_STR, strlen($row['details']) );
			$exc = $stmt->execute();
			if( $exc )
			{
				$nv_Cache->delMod( $module_name );
				Header( 'Location: ' . NV_BASE_ADMINURL . 'index.php?' . NV_LANG_VARIABLE . '=' . NV_LANG_DATA . '&' . NV_NAME_VARIABLE . '=' . $module_name . '&' . NV_OP_VARIABLE . '=' . $op );
				die();
			}
		}
		catch( PDOException $e )
		{
			trigger_error( $e->getMessage() );
			die( $e->getMessage() ); //Remove this line after checks finished
		}
	}
}
elseif( $row['id'] > 0 )
{
	$row = $db->query( 'SELECT * FROM ' . NV_PREFIXLANG . '_' . $module_data . '_rows WHERE id=' . $row['id'] )->fetch();
	if( empty( $row ) )
	{
		Header( 'Location: ' . NV_BASE_ADMINURL . 'index.php?' . NV_LANG_VARIABLE . '=' . NV_LANG_DATA . '&' . NV_NAME_VARIABLE . '=' . $module_name . '&' . NV_OP_VARIABLE . '=' . $op );
		die();
	}
}
else
{
	$row['id'] = 0;
	$row['title'] = '';
	$row['alias'] = '';
	$row['dimension'] = '';
	$row['rooms'] = 1;
	$row['persons_limit'] = 1;
	$row['persons_men'] = 1;
	$row['bed'] = '';
	$row['direct'] = '';
	$row['extrabed'] = '';
	$row['note_extrabed'] = '';
	$row['home_img'] = '';
	$row['home_img_orther'] = '';
	$row['others_img'] = '';
	$row['price'] = '';
	$row['discount'] = 0;
	$row['note_price'] = '';
	$row['hometext'] = '';
	$row['des_tien_ich'] = '';
	$row['details'] = '';
	$row['tien_ich'] = '';
}
if( ! empty( $row['home_img'] ) and is_file( NV_UPLOADS_REAL_DIR . '/' . $module_name . '/' . $row['home_img'] ) )
{
	$row['home_img'] = NV_BASE_SITEURL . NV_UPLOADS_DIR . '/' . $module_name . '/' . $row['home_img'];
}

if( ! empty( $row['home_img_orther'] ) and is_file( NV_UPLOADS_REAL_DIR . '/' . $module_name . '/' . $row['home_img_orther'] ) )
{
	$row['home_img_orther'] = NV_BASE_SITEURL . NV_UPLOADS_DIR . '/' . $module_name . '/' . $row['home_img_orther'];
}

if( defined( 'NV_EDITOR' ) ) require_once NV_ROOTDIR . '/' . NV_EDITORSDIR . '/' . NV_EDITOR . '/nv.php';
$row['des_tien_ich'] = htmlspecialchars( nv_editor_br2nl( $row['des_tien_ich'] ) );
$row['details'] = htmlspecialchars( nv_editor_br2nl( $row['details'] ) );
if( defined( 'NV_EDITOR' ) and nv_function_exists( 'nv_aleditor' ) )
{
	$row['des_tien_ich'] = nv_aleditor( 'des_tien_ich', '100%', '300px', $row['des_tien_ich'] );
	$row['details'] = nv_aleditor( 'details', '100%', '300px', $row['details'] );
}
else
{
	$row['des_tien_ich'] = '<textarea style="width:100%;height:300px" name="des_tien_ich">' . $row['details'] . '</textarea>';
	$row['details'] = '<textarea style="width:100%;height:300px" name="details">' . $row['details'] . '</textarea>';
}


// Fetch Limit
$show_view = false;
if ( ! $nv_Request->isset_request( 'id', 'post,get' ) )
{
	$show_view = true;
	$db->sqlreset()
		->select( '*' )
		->from( '' . NV_PREFIXLANG . '_' . $module_data . '_rows' )
		->order( 'weight ASC' );
	$sth = $db->prepare( $db->sql() );
	$sth->execute();
	//die($db->sql());
}

// lấy danh sách tiện ích ra
$ds_tienich = $db->query('SELECT * FROM '. NV_PREFIXLANG . '_' . $module_data . '_facilities ORDER BY id DESC')->fetchAll();


$xtpl = new XTemplate( $op . '.tpl', NV_ROOTDIR . '/themes/' . $global_config['module_theme'] . '/modules/' . $module_file );
$xtpl->assign( 'LANG', $lang_module );
$xtpl->assign( 'NV_LANG_VARIABLE', NV_LANG_VARIABLE );
$xtpl->assign( 'NV_LANG_DATA', NV_LANG_DATA );
$xtpl->assign( 'NV_BASE_ADMINURL', NV_BASE_ADMINURL );
$xtpl->assign( 'NV_NAME_VARIABLE', NV_NAME_VARIABLE );
$xtpl->assign( 'NV_OP_VARIABLE', NV_OP_VARIABLE );
$xtpl->assign( 'MODULE_NAME', $module_name );
$xtpl->assign( 'OP', $op );
$xtpl->assign( 'ROW', $row );

if( $show_view )
{
	$number = 0;
	$ds = $sth->fetchAll();
	$num_items = $sth->rowCount();
	
	foreach( $ds as $view )
	{
		
		for( $i = 1; $i <= $num_items; ++$i )
		{
			$xtpl->assign( 'WEIGHT', array(
				'key' => $i,
				'title' => $i,
				'selected' => ( $i == $view['weight'] ) ? ' selected="selected"' : '') );
			$xtpl->parse( 'main.view.loop.weight_loop' );
		}
		$view['link_edit'] = NV_BASE_ADMINURL . 'index.php?' . NV_LANG_VARIABLE . '=' . NV_LANG_DATA . '&amp;' . NV_NAME_VARIABLE . '=' . $module_name . '&amp;' . NV_OP_VARIABLE . '=' . $op . '&amp;id=' . $view['id'];
		$view['link_delete'] = NV_BASE_ADMINURL . 'index.php?' . NV_LANG_VARIABLE . '=' . NV_LANG_DATA . '&amp;' . NV_NAME_VARIABLE . '=' . $module_name . '&amp;' . NV_OP_VARIABLE . '=' . $op . '&amp;delete_id=' . $view['id'] . '&amp;delete_checkss=' . md5( $view['id'] . NV_CACHE_PREFIX . $client_info['session_id'] );
		$xtpl->assign( 'VIEW', $view );
		$xtpl->parse( 'main.view.loop' );
	}
	$xtpl->parse( 'main.view' );
}


if( ! empty( $error ) )
{
	$xtpl->assign( 'ERROR', implode( '<br />', $error ) );
	$xtpl->parse( 'main.error' );
}


if(!empty($ds_tienich))
{
	$array_tienich = explode(',',$row['tien_ich']);
	foreach($ds_tienich as $ti)
	{//print_r($ti);die;
		if(in_array($ti['id'],$array_tienich))
		$ti['checked'] = 'checked=checked';
		else $ti['checked'] = '';
		$xtpl->assign( 'tien_ich', $ti );
		$xtpl->parse( 'main.tien_ich' );
	}

}
//so nguoi lơn
for ($i=1;$i<6;$i++){
	if ($i==$row['persons_limit'])
		$selected = " selected='selected'";
	else
		$selected = "";
	$xtpl->assign( 'num', $i );
	$xtpl->assign( 'selected', $selected );
	$xtpl->parse( 'main.person' );
}
//so nguoi tối đa
for ($i=1;$i<11;$i++){
	if ($i==$row['persons_men'])
		$selected = " selected='selected'";
	else
		$selected = "";
	$xtpl->assign( 'num', $i );
	$xtpl->assign( 'selected', $selected );
	$xtpl->parse( 'main.person1' );
}

if( empty( $row['id'] ) )
{
	$xtpl->parse( 'main.auto_get_alias' );
}
//others images
if( !empty( $row['others_img'] ) )
{
	$otherimage = explode( '|', $row['others_img'] );
}
else
{
	$otherimage = array( );
}

$items = 0;
if( !empty( $otherimage ) )
{
	foreach( $otherimage as $otherimage_i )
	{
		$xtpl->assign( 'module_name', $module_name );
		if( !empty( $otherimage_i ) and file_exists( NV_UPLOADS_REAL_DIR . '/' . $module_upload . '/' . $otherimage_i ) )
		{
			$otherimage_i = NV_BASE_SITEURL . NV_UPLOADS_DIR . '/' . $module_upload . '/' . $otherimage_i;
		}
		$data_otherimage_i = array(
			'id' => $items,
			'value' => $otherimage_i
		);
		$xtpl->assign( 'DATAOTHERIMAGE', $data_otherimage_i );
		$xtpl->parse( 'main.otherimage' );
		++$items;
	}
}
$xtpl->assign( 'FILE_ITEMS', $items );


$xtpl->parse( 'main' );
$contents = $xtpl->text( 'main' );

$page_title = $lang_module['main'];

include NV_ROOTDIR . '/includes/header.php';
echo nv_admin_theme( $contents );
include NV_ROOTDIR . '/includes/footer.php';