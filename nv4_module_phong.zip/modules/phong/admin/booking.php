<?php

/**
 * @Project NUKEVIET 4.x
 * @Author VINADES.,JSC (contact@vinades.vn)
 * @Copyright (C) 2015 VINADES.,JSC. All rights reserved
 * @License GNU/GPL version 2 or any later version
 * @Createdate Fri, 11 Sep 2015 08:34:12 GMT
 */

if ( ! defined( 'NV_IS_FILE_ADMIN' ) ) die( 'Stop!!!' );
	
if ( $nv_Request->isset_request( 'delete_book_id', 'get' ) and $nv_Request->isset_request( 'delete_checkss', 'get' ))
{
	$book_id = $nv_Request->get_int( 'delete_book_id', 'get' );
	$delete_checkss = $nv_Request->get_string( 'delete_checkss', 'get' );
	if( $book_id > 0 and $delete_checkss == md5( $book_id . NV_CACHE_PREFIX . $client_info['session_id'] ) )
	{
		$db->query('DELETE FROM ' . NV_PREFIXLANG . '_' . $module_data . '_booking  WHERE book_id = ' . $db->quote( $book_id ) );
		$nv_Cache->delMod( nvtools );
		Header( 'Location: ' . NV_BASE_ADMINURL . 'index.php?' . NV_LANG_VARIABLE . '=' . NV_LANG_DATA . '&' . NV_NAME_VARIABLE . '=' . $module_name . '&' . NV_OP_VARIABLE . '=' . $op );
		die();
	}
}

$row = array();
$error = array();
$row['book_id'] = $nv_Request->get_int( 'book_id', 'post,get', 0 );
if ( $nv_Request->isset_request( 'submit', 'post' ) )
{
	$row['cus_name'] = $nv_Request->get_title( 'cus_name', 'post', '' );
	$row['cus_tel'] = $nv_Request->get_title( 'cus_tel', 'post', '' );
	$row['cus_email'] = $nv_Request->get_title( 'cus_email', 'post', '' );
	$ngay_nhan = $nv_Request->get_title( 'checkin_date', 'post', '' );
	$tra_phong = $nv_Request->get_title( 'checkout_date', 'post', '' );
	$row['adults'] = $nv_Request->get_int( 'adults', 'post', 0 );
	$row['childs'] = $nv_Request->get_int( 'childs', 'post', 0 );
	$row['rooms'] = $nv_Request->get_string( 'rooms', 'post', '' );
	
	if (preg_match('/^([0-9]{1,2})\/([0-9]{1,2})\/([0-9]{4})$/', $tra_phong, $m)) {
        $phour = $nv_Request->get_int('phour', 'post', 0);
        $pmin = $nv_Request->get_int('pmin', 'post', 0);
        $tra_phong = mktime($phour, $pmin, 0, $m[2], $m[1], $m[3]);
		}
		
		if (preg_match('/^([0-9]{1,2})\/([0-9]{1,2})\/([0-9]{4})$/', $ngay_nhan, $m)) {
        $phour = $nv_Request->get_int('phour', 'post', 0);
        $pmin = $nv_Request->get_int('pmin', 'post', 0);
        $ngay_nhan = mktime($phour, $pmin, 0, $m[2], $m[1], $m[3]);
		}

	if( empty( $error ) )
	{
		try
		{
			if( empty( $row['book_id'] ) )
			{

				$row['dateup'] = 0;

				$stmt = $db->prepare( 'INSERT INTO ' . NV_PREFIXLANG . '_' . $module_data . '_booking (cus_name, cus_tel, cus_email, checkin_date, checkout_date, adults, childs, so_luong, dateup) VALUES (:cus_name, :cus_tel, :cus_email, :checkin_date, :checkout_date, :adults, :childs, :rooms, :dateup)' );

				$stmt->bindParam( ':dateup', $row['dateup'], PDO::PARAM_INT );

			}
			else
			{
				$stmt = $db->prepare( 'UPDATE ' . NV_PREFIXLANG . '_' . $module_data . '_booking SET cus_name = :cus_name, cus_tel = :cus_tel, cus_email = :cus_email, checkin_date = :checkin_date, checkout_date = :checkout_date, adults = :adults, childs = :childs, so_luong = :rooms WHERE book_id=' . $row['book_id'] );
			}
			$stmt->bindParam( ':cus_name', $row['cus_name'], PDO::PARAM_STR );
			$stmt->bindParam( ':cus_tel', $row['cus_tel'], PDO::PARAM_STR );
			$stmt->bindParam( ':cus_email', $row['cus_email'], PDO::PARAM_STR );
			$stmt->bindParam( ':checkin_date', $ngay_nhan, PDO::PARAM_INT );
			$stmt->bindParam( ':checkout_date', $tra_phong, PDO::PARAM_INT );
			$stmt->bindParam( ':adults', $row['adults'], PDO::PARAM_INT );
			$stmt->bindParam( ':childs', $row['childs'], PDO::PARAM_INT );
			$stmt->bindParam( ':rooms', $row['rooms'], PDO::PARAM_STR, strlen($row['rooms']) );

			$exc = $stmt->execute();
			if( $exc )
			{
				$nv_Cache->delMod( $module_name );
				Header( 'Location: ' . NV_BASE_ADMINURL . 'index.php?' . NV_LANG_VARIABLE . '=' . NV_LANG_DATA . '&' . NV_NAME_VARIABLE . '=' . $module_name . '&' . NV_OP_VARIABLE . '=' . $op );
				die();
			}
		}
		catch( PDOException $e )
		{
			trigger_error( $e->getMessage() );
			die( $e->getMessage() ); //Remove this line after checks finished
		}
	}
}
elseif( $row['book_id'] > 0 )
{
	$row = $db->query( 'SELECT * FROM ' . NV_PREFIXLANG . '_' . $module_data . '_booking WHERE book_id=' . $row['book_id'] )->fetch();
	//lấy thông tin phòng 
	$kq = $db->query('select * from '. NV_PREFIXLANG . '_' . $module_data . '_rows where id='.$row['id_sp'])->fetch();
		$tien = $kq['price'] * $row['so_luong'];
		$tongtien = number_format($tien);
		$row['title'] = $kq['title'];
		if($kq['price'] > 0)
		$row['price'] = number_format($kq['price']);
		$row['persons_men'] = $kq['persons_men'];
		$row['persons_limit'] = $kq['persons_limit'];
		$row['extrabed'] = $kq['extrabed'];
		$row['tien'] = $tongtien;
	if( empty( $row ) )
	{
		Header( 'Location: ' . NV_BASE_ADMINURL . 'index.php?' . NV_LANG_VARIABLE . '=' . NV_LANG_DATA . '&' . NV_NAME_VARIABLE . '=' . $module_name . '&' . NV_OP_VARIABLE . '=' . $op );
		die();
	}
	$thong_tin_sp = $db->query( 'SELECT * FROM ' . NV_PREFIXLANG . '_' . $module_data . '_rows WHERE id=' . $row['id_sp'] )->fetch();
	
}
else
{
	$row['book_id'] = 0;
	$row['cus_name'] = '';
	$row['cus_tel'] = '';
	$row['cus_email'] = '';
	$row['checkin_date'] = '';
	$row['checkout_date'] = '';
	$row['adults'] = 0;
	$row['childs'] = 0;
	$row['rooms'] = '';
}

$q = $nv_Request->get_title( 'q', 'post,get' );

// Fetch Limit
$show_view = false;
if ( ! $nv_Request->isset_request( 'id', 'post,get' ) )
{
	$show_view = true;
	$per_page = 5;
	$page = $nv_Request->get_int( 'page', 'post,get', 1 );
	$db->sqlreset()
		->select( 'COUNT(*)' )
		->from( '' . NV_PREFIXLANG . '_' . $module_data . '_booking' );

	if( ! empty( $q ) )
	{
		$db->where( 'cus_name LIKE :q_cus_name OR checkin_date LIKE :q_checkin_date OR checkout_date LIKE :q_checkout_date OR adults LIKE :q_adults OR childs LIKE :q_childs OR rooms LIKE :q_rooms OR dateup LIKE :q_dateup' );
	}
	$sth = $db->prepare( $db->sql() );

	if( ! empty( $q ) )
	{
		$sth->bindValue( ':q_cus_name', '%' . $q . '%' );
		$sth->bindValue( ':q_checkin_date', '%' . $q . '%' );
		$sth->bindValue( ':q_checkout_date', '%' . $q . '%' );
		$sth->bindValue( ':q_adults', '%' . $q . '%' );
		$sth->bindValue( ':q_childs', '%' . $q . '%' );
		$sth->bindValue( ':q_rooms', '%' . $q . '%' );
		$sth->bindValue( ':q_dateup', '%' . $q . '%' );
	}
	$sth->execute();
	$num_items = $sth->fetchColumn();

	$db->select( '*' )
		->order( 'book_id DESC' )
		->limit( $per_page )
		->offset( ( $page - 1 ) * $per_page );
	$sth = $db->prepare( $db->sql() );

	if( ! empty( $q ) )
	{
		$sth->bindValue( ':q_cus_name', '%' . $q . '%' );
		$sth->bindValue( ':q_checkin_date', '%' . $q . '%' );
		$sth->bindValue( ':q_checkout_date', '%' . $q . '%' );
		$sth->bindValue( ':q_adults', '%' . $q . '%' );
		$sth->bindValue( ':q_childs', '%' . $q . '%' );
		$sth->bindValue( ':q_rooms', '%' . $q . '%' );
		$sth->bindValue( ':q_dateup', '%' . $q . '%' );
	}
	$sth->execute();
}


$xtpl = new XTemplate( $op . '.tpl', NV_ROOTDIR . '/themes/' . $global_config['module_theme'] . '/modules/' . $module_file );
$xtpl->assign( 'LANG', $lang_module );
$xtpl->assign( 'NV_LANG_VARIABLE', NV_LANG_VARIABLE );
$xtpl->assign( 'NV_LANG_DATA', NV_LANG_DATA );
$xtpl->assign( 'NV_BASE_ADMINURL', NV_BASE_ADMINURL );
$xtpl->assign( 'NV_BASE_SITEURL', NV_BASE_SITEURL );
$xtpl->assign( 'NV_NAME_VARIABLE', NV_NAME_VARIABLE );
$xtpl->assign( 'NV_OP_VARIABLE', NV_OP_VARIABLE );
$xtpl->assign( 'MODULE_NAME', $module_name );
$xtpl->assign( 'OP', $op );
if(isset($_REQUEST['book_id']))
{
$row['checkin_date'] = date('d/m/Y',$row['checkin_date']);
$row['checkout_date'] = date('d/m/Y',$row['checkout_date']);
$xtpl->assign( 'ROW', $row );
$xtpl->parse( 'main.booking' );
}
//$xtpl->assign( 'SP', $thong_tin_sp );
$xtpl->assign( 'Q', $q );

if( $show_view )
{
	$base_url = NV_BASE_ADMINURL . 'index.php?' . NV_LANG_VARIABLE . '=' . NV_LANG_DATA . '&amp;' . NV_NAME_VARIABLE . '=' . $module_name . '&amp;' . NV_OP_VARIABLE . '=' . $op;
	if( ! empty( $q ) )
	{
		$base_url .= '&q=' . $q;
	}
	$xtpl->assign( 'NV_GENERATE_PAGE', nv_generate_page( $base_url, $num_items, $per_page, $page) );

	$number = 0;
	while( $view = $sth->fetch() )
	{		
		$kq = $db->query('select title, price, persons_men from '. NV_PREFIXLANG . '_' . $module_data . '_rows where id='.$view['id_sp'])->fetch();
		$tien = $kq['price'] * $view['so_luong'];
		$tongtien = number_format($tien);
		$view['title'] = $kq['title'];
		$view['tien'] = $tongtien;
		$view['persons_men'] = $kq['persons_men'];
		$view['number'] = ++$number;
		$view['link_edit'] = NV_BASE_ADMINURL . 'index.php?' . NV_LANG_VARIABLE . '=' . NV_LANG_DATA . '&amp;' . NV_NAME_VARIABLE . '=' . $module_name . '&amp;' . NV_OP_VARIABLE . '=' . $op . '&amp;book_id=' . $view['book_id'];
		$view['link_delete'] = NV_BASE_ADMINURL . 'index.php?' . NV_LANG_VARIABLE . '=' . NV_LANG_DATA . '&amp;' . NV_NAME_VARIABLE . '=' . $module_name . '&amp;' . NV_OP_VARIABLE . '=' . $op . '&amp;delete_book_id=' . $view['book_id'] . '&amp;delete_checkss=' . md5( $view['book_id'] . NV_CACHE_PREFIX . $client_info['session_id'] );
		$view['dateup'] = date('d/m/Y',$view['dateup']);
		$view['checkin_date'] = date('d/m/Y',$view['checkin_date']);
		$view['checkout_date'] = date('d/m/Y',$view['checkout_date']);
		$xtpl->assign( 'VIEW', $view );
		$xtpl->parse( 'main.view.loop' );
	}
	$xtpl->parse( 'main.view' );
}


if( ! empty( $error ) )
{
	$xtpl->assign( 'ERROR', implode( '<br />', $error ) );
	$xtpl->parse( 'main.error' );
}
if( empty( $row['book_id'] ) )
{
	$xtpl->parse( 'main.auto_get_alias' );
}
$xuat_file = NV_BASE_ADMINURL . 'index.php?' . NV_LANG_VARIABLE . '=' . NV_LANG_DATA . '&amp;' . NV_NAME_VARIABLE . '=' . $module_name . '&amp;' . NV_OP_VARIABLE . '=excel';
$xtpl->assign( 'XUAT_FILE', $xuat_file);
$xtpl->parse( 'main' );
$contents = $xtpl->text( 'main' );

$page_title = $lang_module['booking'];

include NV_ROOTDIR . '/includes/header.php';
echo nv_admin_theme( $contents );
include NV_ROOTDIR . '/includes/footer.php';