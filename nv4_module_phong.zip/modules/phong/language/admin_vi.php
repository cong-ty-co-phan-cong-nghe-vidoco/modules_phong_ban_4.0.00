<?php

/**
 * @Project NUKEVIET 4.x
 * @Author VINADES.,JSC (contact@vinades.vn)
 * @Copyright (C) 2015 VINADES.,JSC. All rights reserved
 * @License GNU/GPL version 2 or any later version
 * @Createdate Tue, 08 Sep 2015 03:18:03 GMT
 */

if ( ! defined( 'NV_MAINFILE' ) ) die( 'Stop!!!' );

$lang_translator['author'] = 'VINADES.,JSC (contact@vinades.vn)';
$lang_translator['createdate'] = '08/09/2015, 03:18';
$lang_translator['copyright'] = '@Copyright (C) 2015 VINADES.,JSC All rights reserved';
$lang_translator['info'] = '';
$lang_translator['langtype'] = 'lang_module';

$lang_module['main'] = 'Danh sách phòng';
$lang_module['config'] = 'Cấu hình';
$lang_module['viewcat'] = 'Danh mục phòng';
$lang_module['facilities'] = 'Tiện nghi phòng';
$lang_module['booking'] = 'Liên hệ đặt phòng';
$lang_module['save'] = 'Save';

//Lang for function cat
$lang_module['cat'] = 'Danh mục phòng';
$lang_module['tien_ich'] = 'Tiện ích';

$lang_module['edit'] = 'Sửa';
$lang_module['delete'] = 'Xóa';
$lang_module['number'] = 'STT';
$lang_module['search_title'] = 'Nhập từ khóa tìm kiếm';
$lang_module['search_submit'] = 'Tìm kiếm';
$lang_module['cat_title'] = 'Tiêu đề';
$lang_module['cat_alias'] = 'Liên kết tĩnh';
$lang_module['cat_hometext'] = 'Mô tả';
$lang_module['cat_detail'] = 'Chi tiết';
$lang_module['cate_homeimg'] = 'Hình minh họa';
$lang_module['cat_dateup'] = 'Cat dateup';

//Lang for function cat
$lang_module['cat_weight'] = 'Thứ tự';

//Lang for function facilities
$lang_module['title'] = 'Tiêu đề';

//Lang for function main
$lang_module['room_type'] = 'Loại phòng';
$lang_module['catid'] = 'Catid';
$lang_module['alias'] = 'Liên kết tĩnh';
$lang_module['dimension'] = 'Diện tích';
$lang_module['rooms'] = 'Số lượng phòng';
$lang_module['persons_limit'] = 'Số người tối đa';
$lang_module['bed'] = 'Giường ngủ';
$lang_module['direct'] = 'Hướng';
$lang_module['extrabed'] = 'Giường phụ - Trẻ em';
$lang_module['note_extrabed'] = 'Ghi chú giường phụ';
$lang_module['home_img'] = 'Hình minh họa';
$lang_module['home_img_orther'] = 'Hình minh họa khác';
$lang_module['others_img'] = 'Hình ảnh khác';
$lang_module['price'] = 'Giá';
$lang_module['discount'] = 'Khuyến mãi';
$lang_module['note_price'] = 'Ghi chú giá';
$lang_module['hometext'] = 'Mô tả phòng';
$lang_module['des_tienich'] = 'Giá bao gồm';
$lang_module['details'] = 'Chi tiết phòng';
$lang_module['dateup'] = 'Ngày cập nhật';

//Lang for function booking
$lang_module['cus_name'] = 'Họ tên';
$lang_module['cus_tel'] = 'Điện thoại';
$lang_module['cus_email'] = 'Email';
$lang_module['checkin_date'] = 'Ngày nhận';
$lang_module['checkout_date'] = 'Ngày trả';
$lang_module['adults'] = 'Số người lớn';
$lang_module['childs'] = 'Số trẻ em';

//Lang for function config
$lang_module['currency'] = 'Tiền';
