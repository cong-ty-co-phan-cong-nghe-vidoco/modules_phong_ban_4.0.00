<?php

/**
 * @Project NUKEVIET 4.x
 * @Author VINADES.,JSC (contact@vinades.vn)
 * @Copyright (C) 2015 VINADES.,JSC. All rights reserved
 * @License GNU/GPL version 2 or any later version
 * @Createdate Tue, 08 Sep 2015 03:18:03 GMT
 */

if ( ! defined( 'NV_MAINFILE' ) ) die( 'Stop!!!' );

$lang_translator['author'] = 'VINADES.,JSC (contact@vinades.vn)';
$lang_translator['createdate'] = '08/09/2015, 03:18';
$lang_translator['copyright'] = '@Copyright (C) 2015 VINADES.,JSC All rights reserved';
$lang_translator['info'] = '';
$lang_translator['langtype'] = 'lang_module';

$lang_module['main'] = 'Room list';
$lang_module['config'] = 'Config';
$lang_module['viewcat'] = 'Category';
$lang_module['facilities'] = 'Facilities';
$lang_module['booking'] = 'Booking';
$lang_module['save'] = 'Save';



//Lang for function cat
$lang_module['cat'] = 'cat';
$lang_module['edit'] = 'Edit';
$lang_module['delete'] = 'Delete';
$lang_module['tien_ich'] = 'Utilities';
$lang_module['number'] = 'Number';
$lang_module['search_title'] = 'Enter keywords searching';
$lang_module['search_submit'] = 'Search';
$lang_module['cat_title'] = 'Cat title';
$lang_module['cat_alias'] = 'Cat alias';
$lang_module['cat_hometext'] = 'Cat hometext';
$lang_module['cat_detail'] = 'Cat detail';
$lang_module['cate_homeimg'] = 'Cate homeimg';
$lang_module['cat_dateup'] = 'Cat dateup';

//Lang for function cat
$lang_module['cat_weight'] = 'Cat weight';

//Lang for function facilities
$lang_module['title'] = 'Title';

//Lang for function main
$lang_module['room_type'] = 'Type rooms';
$lang_module['catid'] = 'Catid';
$lang_module['alias'] = 'Alias';
$lang_module['dimension'] = 'Dimension';
$lang_module['rooms'] = 'Rooms';
$lang_module['persons_limit'] = 'Persons limit';
$lang_module['bed'] = 'Bed';
$lang_module['direct'] = 'Direct';
$lang_module['extrabed'] = 'Extrabed';
$lang_module['note_extrabed'] = 'Note extrabed';
$lang_module['home_img'] = 'Home img';
$lang_module['home_img_orther'] = 'Other home img';
$lang_module['others_img'] = 'Others img';
$lang_module['price'] = 'Price';
$lang_module['discount'] = 'Discount';
$lang_module['note_price'] = 'Note price';
$lang_module['hometext'] = 'Room description';
$lang_module['des_tienich'] = 'Utility Room';
$lang_module['details'] = 'Details';
$lang_module['dateup'] = 'Dateup';

//Lang for function booking
$lang_module['cus_name'] = 'Cus name';
$lang_module['cus_tel'] = 'Cus tel';
$lang_module['cus_email'] = 'Cus email';
$lang_module['checkin_date'] = 'Checkin date';
$lang_module['checkout_date'] = 'Checkout date';
$lang_module['adults'] = 'Adults';
$lang_module['childs'] = 'Childs';

//Lang for function config
$lang_module['currency'] = 'Currency';
