<?php

/**
 * @Project NUKEVIET 4.x
 * @Author VINADES.,JSC (contact@vinades.vn)
 * @Copyright (C) 2015 VINADES.,JSC. All rights reserved
 * @License GNU/GPL version 2 or any later version
 * @Createdate Tue, 08 Sep 2015 03:18:03 GMT
 */

if ( ! defined( 'NV_MAINFILE' ) ) die( 'Stop!!!' );

$lang_translator['author'] = 'VINADES.,JSC (contact@vinades.vn)';
$lang_translator['createdate'] = '08/09/2015, 03:18';
$lang_translator['copyright'] = '@Copyright (C) 2015 VINADES.,JSC. All rights reserved';
$lang_translator['info'] = '';
$lang_translator['langtype'] = 'lang_module';

$lang_module['main'] = "Main";
$lang_module['detail'] = "Detail";
$lang_module['search'] = "Search";
$lang_module['viewcat'] = "Viewcat";
$lang_module['booking'] = "Book room";
$lang_module['tim_phong'] = 'Find room';
$lang_module['room_type'] = 'Room type';
$lang_module['persons_limit'] = 'Limit';
$lang_module['price'] = 'Price';
$lang_module['rooms'] = 'Rooms';
$lang_module['detail'] = 'Detail';
$lang_module['dimension'] = 'Dimension';
$lang_module['xemtatcakm'] = 'View All Service';
$lang_module['bed'] = 'Bed type';
$lang_module['direction'] = 'Direction';
$lang_module['donvi'] = 'VNĐ / Night';
$lang_module['extrabed'] = 'Children and Extra bed';
$lang_module['features'] = 'Room facilities';

$lang_module['room_info'] = 'Room information';
$lang_module['not_moneyback'] = 'No money back';

$lang_module['room_toida'] = 'Maximum ';
$lang_module['question'] = 'If you </br> travel adult children socks or need extra beds , please click on the icon " ? " for more details';


$lang_module['fullname'] = 'Your name';
$lang_module['email'] = 'Email';
$lang_module['captcha'] = 'Security code';
$lang_module['title'] = 'Subject';
$lang_module['address'] = 'Address';
$lang_module['tinhthanh'] = 'City provincial';
$lang_module['quocgia'] = 'The country';
$lang_module['nhan'] = 'Check in';
$lang_module['tra'] = 'Check out';
$lang_module['null'] = 'Null';
$lang_module['cat'] = 'Category';
$lang_module['selectCat'] = 'Choose a category of message';
$lang_module['part'] = 'Recipient';
$lang_module['content'] = 'Your message';
$lang_module['reset'] = 'Clear';
$lang_module['sendcontact'] = 'Send';
$lang_module['error_fullname'] = 'Please enter your full name';
$lang_module['error_email'] = 'Please enter your email';
$lang_module['error_captcha'] = 'Error: Security code incorrect';
$lang_module['error_title'] = 'Error: Please enter the subject';
$lang_module['error_content'] = 'Please enter your message';
$lang_module['sendcontactok'] = 'Thank you! We will reply as soon as possible.';
$lang_module['sendinfo'] = 'This email sent by contact function at website';
$lang_module['sendinfo2'] = 'Sender information';
$lang_module['phone'] = 'Phone number';
$lang_module['fax'] = 'Fax';
$lang_module['note_s'] = 'Note';
$lang_module['nhan'] = 'Check in room';
$lang_module['tra'] = 'Check room';
$lang_module['nnhan'] = 'Check in';
$lang_module['ntra'] = 'Check out';
$lang_module['tntt'] = 'Room information';
$lang_module['sntd'] = 'Maximum number of users';
$lang_module['toida'] = 'Adults';
$lang_module['treem'] = 'Extra beds - Children';
$lang_module['ntreem'] = 'Children';
$lang_module['room_type'] = 'Kind of room';
$lang_module['motatienich'] = 'Equipment in the room';
$lang_module['others_room'] = 'Other rooms';
$lang_module['department'] = 'Department';
$lang_module['sendcontactfailed'] = 'Your feedback was not sent because of technical reasons. Sorry for the inconvenience.';
$lang_module['note'] = 'Please complete all required fields.';
$lang_module['thongtin'] = 'Contact Info';
$lang_module['chitietphong'] = 'Room Details';
$lang_module['thanhtoan'] = 'Receiving payment and rubbing';
$lang_module['tt_nhanphong'] = 'Payment upon arrival';
$lang_module['tt_chuyenkhoan'] = 'Payment via bank transfer';
$lang_module['hoanthanh'] = 'Complete';
$lang_module['phong'] = 'Room';
$lang_module['soluong'] = 'Number';
$lang_module['phong_ngu'] = 'Bedroom';
$lang_module['dem'] = 'Night';
$lang_module['tongtien'] = 'Total Money';
$lang_module['doiphong'] = 'Changing the room';
$lang_module['doingay'] = 'Changing day';
$lang_module['null'] = 'Null';
$lang_module['ok_room'] = 'Reservation is successful. We will contact you soon. Thank you!';
$lang_module['contact1'] = 'Please contact';
$lang_module['contact'] = 'Contact';

