<?php

/**
 * @Project NUKEVIET 4.x
 * @Author VINADES.,JSC (contact@vinades.vn)
 * @Copyright (C) 2015 VINADES.,JSC. All rights reserved
 * @License GNU/GPL version 2 or any later version
 * @Createdate Tue, 08 Sep 2015 03:18:03 GMT
 */

if ( ! defined( 'NV_MAINFILE' ) ) die( 'Stop!!!' );

$lang_translator['author'] = 'VINADES.,JSC (contact@vinades.vn)';
$lang_translator['createdate'] = '08/09/2015, 03:18';
$lang_translator['copyright'] = '@Copyright (C) 2015 VINADES.,JSC. All rights reserved';
$lang_translator['info'] = '';
$lang_translator['langtype'] = 'lang_module';

$lang_module['tienich'] = 'Tiện ích';
$lang_module['phongkhac'] = 'Phòng liên quan';
$lang_module['main'] = 'Trang chính';
$lang_module['detail'] = 'Chi tiết phòng';
$lang_module['search'] = 'Tìm kiếm';
$lang_module['viewcat'] = 'Chọn phòng của bạn';
$lang_module['booking'] = 'Đặt phòng';

$lang_module['room_type'] = 'Loại phòng';
$lang_module['xemtatcakm'] = 'Xem tất cả các dịch vụ';
$lang_module['persons_limit'] = 'Tối đa';
$lang_module['price'] = 'Giá phòng';
$lang_module['rooms'] = 'Số phòng';
$lang_module['dimension'] = 'Diện tích phòng';
$lang_module['detail'] = 'Chi tiết';
$lang_module['bed'] = 'Giường';
$lang_module['donvi'] = 'đ';
$lang_module['direction'] = 'Hướng';
$lang_module['extrabed'] = 'Trẻ em và giường phụ';
$lang_module['features'] = 'Đặc điểm phòng';

$lang_module['others_room'] = 'Phòng khác';
$lang_module['motatienich'] = 'Giá bao gồm';


$lang_module['room_toida'] = 'Tối đa ';
$lang_module['room_info'] = 'Thông tin phòng';
$lang_module['question'] = 'người lớn<br>Nếu bạn du lịch với trẻ em hoặc cần thêm giường phụ, vui lòng nhấn chuột vào biểu tượng "?" để biết thêm chi tiết';
$lang_module['not_moneyback'] = 'Không hoàn tiền';


$lang_module['fullname'] = 'Họ tên';
$lang_module['email'] = 'Email';
$lang_module['captcha'] = 'Mã bảo mật';
$lang_module['title'] = 'Tiêu đề';
$lang_module['cat'] = 'Chủ đề';
$lang_module['selectCat'] = 'Chủ đề bạn quan tâm';
$lang_module['part'] = 'Gửi đến bộ phận';
$lang_module['content'] = 'Nội dung';
$lang_module['reset'] = 'Nhập lại';
$lang_module['sendcontact'] = 'Gửi đi';
$lang_module['error_fullname'] = 'Vui lòng nhập họ và tên';
$lang_module['error_email'] = 'Vui lòng nhập email khả dụng';
$lang_module['error_captcha'] = 'Vui lòng nhập đúng mã bảo mật mà bạn thấy trong hình';
$lang_module['error_title'] = 'Vui lòng nhập tiêu đề';
$lang_module['error_content'] = 'Vui lòng nhập nội dung';
$lang_module['sendcontactok'] = 'Cảm ơn bạn đã quan tâm! Chúng tôi sẽ trả lời thư của bạn trong thời gian sớm nhất.';
$lang_module['sendinfo'] = "Thư này được gửi thông qua tiện ích Liên hệ tại website";
$lang_module['sendinfo2'] = "Thông tin về người gửi";
$lang_module['phone'] = 'Điện thoại';
$lang_module['address'] = 'Địa chỉ';
$lang_module['tinhthanh'] = 'Tỉnh thành';
$lang_module['quocgia'] = 'Quốc gia';
$lang_module['reset'] = 'Làm lại';
$lang_module['fax'] = 'Fax';
$lang_module['note_s'] = 'Ghi chú';
$lang_module['thongtin'] = 'Thông tin liên hệ';
$lang_module['chitietphong'] = 'Chi tiết phòng';
$lang_module['nhan'] = 'Nhận phòng';
$lang_module['tra'] = 'Trả phòng';
$lang_module['nnhan'] = 'Ngày nhận phòng';
$lang_module['ntra'] = 'Ngày trả phòng';
$lang_module['tntt'] = 'Thông tin phòng';
$lang_module['thanhtoan'] = 'Thanh toán và xát nhận';
$lang_module['tt_nhanphong'] = 'Thanh toán khi nhận phòng';
$lang_module['tt_chuyenkhoan'] = 'Thanh toán qua chuyển khoản';
$lang_module['sntd'] = 'Số người tối đa';
$lang_module['toida'] = 'Người lớn';
$lang_module['treem'] = 'Giường phụ - Trẻ em';
$lang_module['ntreem'] = 'Trẻ em';
$lang_module['tim_phong'] = 'Tìm phòng';
$lang_module['phong'] = 'Phòng';
$lang_module['soluong'] = 'Số lượng';
$lang_module['phong_ngu'] = 'Phòng ngủ';
$lang_module['dem'] = 'Đêm';
$lang_module['tongtien'] = 'Tổng tiền';
$lang_module['doiphong'] = 'Đổi phòng';
$lang_module['hoanthanh'] = 'Hoàn thành';
$lang_module['doingay'] = 'Đổi ngày';
$lang_module['null'] = 'Trống';
$lang_module['loai_phong'] = 'Loại phòng';
$lang_module['chontatca'] = 'Chọn tất cả';
$lang_module['hetphong'] = 'Hết phòng';
$lang_module['thanhtoan'] = 'Thanh toán và liên hệ';
$lang_module['department'] = 'Bộ phận';
$lang_module['nnhan'] = 'Ngày nhận';
$lang_module['ntra'] = 'Ngày trả';
$lang_module['room_type'] = 'Loại phòng';
$lang_module['contact1'] = 'Vui lòng liên hệ';
$lang_module['contact'] = 'Liên hệ';
$lang_module['price'] = 'Giá';
$lang_module['ok_room'] = 'Đặt phòng thành công. Chúng tôi sẽ sớm liên hệ với bạn. Cảm ơn!';
$lang_module['select_room_type'] = 'Chọn loại phòng';
$lang_module['sendcontactfailed'] = 'Phản hồi của bạn đã không được gửi đi vì lý do kỹ thuật. Thành thật xin lỗi vì sự bất tiện này.';
$lang_module['note'] = 'Vui lòng điền vào mẫu dưới đây và chúng tôi sẽ liên lạc với bạn.';


